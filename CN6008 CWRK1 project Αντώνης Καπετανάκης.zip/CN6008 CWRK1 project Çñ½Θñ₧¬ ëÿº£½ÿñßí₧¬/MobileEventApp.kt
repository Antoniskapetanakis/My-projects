<html>
  <head>
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="" />
    <link
      rel="stylesheet"
      as="style"
      onload="this.rel='stylesheet'"
      href="https://fonts.googleapis.com/css2?display=swap&amp;family=Noto+Sans%3Awght%40400%3B500%3B700%3B900&amp;family=Plus+Jakarta+Sans%3Awght%40400%3B500%3B700%3B800"
    />

    <title>Galileo Design</title>
    <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64," />

    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  </head>
  <body>
    <div
      class="relative flex size-full min-h-screen flex-col bg-white justify-between group/design-root overflow-x-hidden"
      style='font-family: "Plus Jakarta Sans", "Noto Sans", sans-serif;'
    >
      <div>
        <div class="flex items-center bg-white p-4 pb-2 justify-between">
          <div class="text-[#111518] flex size-12 shrink-0 items-center" data-icon="MapPin" data-size="24px" data-weight="regular">
            <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
              <path
                d="M128,64a40,40,0,1,0,40,40A40,40,0,0,0,128,64Zm0,64a24,24,0,1,1,24-24A24,24,0,0,1,128,128Zm0-112a88.1,88.1,0,0,0-88,88c0,31.4,14.51,64.68,42,96.25a254.19,254.19,0,0,0,41.45,38.3,8,8,0,0,0,9.18,0A254.19,254.19,0,0,0,174,200.25c27.45-31.57,42-64.85,42-96.25A88.1,88.1,0,0,0,128,16Zm0,206c-16.53-13-72-60.75-72-118a72,72,0,0,1,144,0C200,161.23,144.53,209,128,222Z"
              ></path>
            </svg>
          </div>
          <h2 class="text-[#111518] text-lg font-bold leading-tight tracking-[-0.015em] flex-1">San Francisco</h2>
          <div class="flex w-12 items-center justify-end">
            <button
              class="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-12 bg-transparent text-[#111518] gap-2 text-base font-bold leading-normal tracking-[0.015em] min-w-0 p-0"
            >
              <div class="text-[#111518]" data-icon="MagnifyingGlass" data-size="24px" data-weight="regular">
                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                  <path d="M229.66,218.34l-50.07-50.06a88.11,88.11,0,1,0-11.31,11.31l50.06,50.07a8,8,0,0,0,11.32-11.32ZM40,112a72,72,0,1,1,72,72A72.08,72.08,0,0,1,40,112Z"></path>
                </svg>
              </div>
            </button>
          </div>
        </div>
        <div class="flex gap-3 p-3 overflow-x-hidden">
          <div class="flex h-8 shrink-0 items-center justify-center gap-x-2 rounded-xl bg-[#f0f2f5] pl-4 pr-4">
            <p class="text-[#111518] text-sm font-medium leading-normal">Concerts</p>
          </div>
          <div class="flex h-8 shrink-0 items-center justify-center gap-x-2 rounded-xl bg-[#f0f2f5] pl-4 pr-4">
            <p class="text-[#111518] text-sm font-medium leading-normal">Comedy</p>
          </div>
          <div class="flex h-8 shrink-0 items-center justify-center gap-x-2 rounded-xl bg-[#f0f2f5] pl-4 pr-4">
            <p class="text-[#111518] text-sm font-medium leading-normal">Theater</p>
          </div>
          <div class="flex h-8 shrink-0 items-center justify-center gap-x-2 rounded-xl bg-[#f0f2f5] pl-4 pr-4">
            <p class="text-[#111518] text-sm font-medium leading-normal">Sports</p>
          </div>
          <div class="flex h-8 shrink-0 items-center justify-center gap-x-2 rounded-xl bg-[#f0f2f5] pl-4 pr-4">
            <p class="text-[#111518] text-sm font-medium leading-normal">Museums</p>
          </div>
        </div>
        <h3 class="text-[#111518] text-lg font-bold leading-tight tracking-[-0.015em] px-4 pb-2 pt-4">Top events near you</h3>
        <div class="p-4">
          <div class="flex items-stretch justify-between gap-4 rounded-xl">
            <div class="flex flex-[2_2_0px] flex-col gap-4">
              <div class="flex flex-col gap-1">
                <p class="text-[#60778a] text-sm font-normal leading-normal">Tonight</p>
                <p class="text-[#111518] text-base font-bold leading-tight">A Night with the Stars</p>
                <p class="text-[#60778a] text-sm font-normal leading-normal">The Grand Ballroom | 8:00 PM</p>
              </div>
              <button
                class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-8 px-4 flex-row-reverse bg-[#f0f2f5] text-[#111518] text-sm font-medium leading-normal w-fit"
              >
                <span class="truncate">See Details</span>
              </button>
            </div>
            <div
              class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl flex-1"
              style='background-image: url("https://cdn.usegalileo.ai/sdxl10/982e9c30-15d7-417b-95fe-b63249aa2af2.png");'
            ></div>
          </div>
        </div>
        <div class="p-4">
          <div class="flex items-stretch justify-between gap-4 rounded-xl">
            <div class="flex flex-[2_2_0px] flex-col gap-4">
              <div class="flex flex-col gap-1">
                <p class="text-[#60778a] text-sm font-normal leading-normal">Tomorrow</p>
                <p class="text-[#111518] text-base font-bold leading-tight">City Comedy Fest</p>
                <p class="text-[#60778a] text-sm font-normal leading-normal">Laugh Lounge | 7:30 PM</p>
              </div>
              <button
                class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-8 px-4 flex-row-reverse bg-[#f0f2f5] text-[#111518] text-sm font-medium leading-normal w-fit"
              >
                <span class="truncate">See Details</span>
              </button>
            </div>
            <div
              class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl flex-1"
              style='background-image: url("https://cdn.usegalileo.ai/sdxl10/d6c3c4e4-ca7c-433b-a2ff-aa6c3bfe71ce.png");'
            ></div>
          </div>
        </div>
        <div class="p-4">
          <div class="flex items-stretch justify-between gap-4 rounded-xl">
            <div class="flex flex-[2_2_0px] flex-col gap-4">
              <div class="flex flex-col gap-1">
                <p class="text-[#60778a] text-sm font-normal leading-normal">This Weekend</p>
                <p class="text-[#111518] text-base font-bold leading-tight">Golden Gate Theater Presents: Hamlet</p>
                <p class="text-[#60778a] text-sm font-normal leading-normal">Golden Gate Theater | 2:00 PM</p>
              </div>
              <button
                class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-8 px-4 flex-row-reverse bg-[#f0f2f5] text-[#111518] text-sm font-medium leading-normal w-fit"
              >
                <span class="truncate">See Details</span>
              </button>
            </div>
            <div
              class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl flex-1"
              style='background-image: url("https://cdn.usegalileo.ai/sdxl10/df0969bb-6f26-46d5-b424-30cb3fccf799.png");'
            ></div>
          </div>
        </div>
        <h3 class="text-[#111518] text-lg font-bold leading-tight tracking-[-0.015em] px-4 pb-2 pt-4">Nearby Venues</h3>
        <div class="p-4">
          <div class="flex items-stretch justify-between gap-4 rounded-xl">
            <div class="flex flex-[2_2_0px] flex-col gap-4">
              <div class="flex flex-col gap-1">
                <p class="text-[#111518] text-base font-bold leading-tight">The Grand Ballroom</p>
                <p class="text-[#60778a] text-sm font-normal leading-normal">578 Mission Street | Music Events</p>
              </div>
              <button
                class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-8 px-4 flex-row-reverse bg-[#f0f2f5] text-[#111518] text-sm font-medium leading-normal w-fit"
              >
                <span class="truncate">View Events</span>
              </button>
            </div>
            <div
              class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl flex-1"
              style='background-image: url("https://cdn.usegalileo.ai/sdxl10/2f297124-78d1-4514-b826-b681ac4acae9.png");'
            ></div>
          </div>
        </div>
        <div class="p-4">
          <div class="flex items-stretch justify-between gap-4 rounded-xl">
            <div class="flex flex-[2_2_0px] flex-col gap-4">
              <div class="flex flex-col gap-1">
                <p class="text-[#111518] text-base font-bold leading-tight">Laugh Lounge</p>
                <p class="text-[#60778a] text-sm font-normal leading-normal">123 Howard Street | Comedy Events</p>
              </div>
              <button
                class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-8 px-4 flex-row-reverse bg-[#f0f2f5] text-[#111518] text-sm font-medium leading-normal w-fit"
              >
                <span class="truncate">View Events</span>
              </button>
            </div>
            <div
              class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl flex-1"
              style='background-image: url("https://cdn.usegalileo.ai/sdxl10/ccac4714-e801-4448-ae18-5eb4022fcfea.png");'
            ></div>
          </div>
        </div>
        <div class="p-4">
          <div class="flex items-stretch justify-between gap-4 rounded-xl">
            <div class="flex flex-[2_2_0px] flex-col gap-4">
              <div class="flex flex-col gap-1">
                <p class="text-[#111518] text-base font-bold leading-tight">Golden Gate Theater</p>
                <p class="text-[#60778a] text-sm font-normal leading-normal">1 Taylor Street | Theatrical Performances</p>
              </div>
              <button
                class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-8 px-4 flex-row-reverse bg-[#f0f2f5] text-[#111518] text-sm font-medium leading-normal w-fit"
              >
                <span class="truncate">View Events</span>
              </button>
            </div>
            <div
              class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl flex-1"
              style='background-image: url("https://cdn.usegalileo.ai/sdxl10/c8331e62-fa14-4f25-85d8-19aa7c13a526.png");'
            ></div>
          </div>
        </div>
      </div>
      <div>
        <div class="flex gap-2 border-t border-[#f0f2f5] bg-white px-4 pb-3 pt-2">
          <a class="just flex flex-1 flex-col items-center justify-end gap-1 rounded-full text-[#111518]" href="#">
            <div class="text-[#111518] flex h-8 items-center justify-center" data-icon="House" data-size="24px" data-weight="fill">
              <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                <path
                  d="M224,115.55V208a16,16,0,0,1-16,16H168a16,16,0,0,1-16-16V168a8,8,0,0,0-8-8H112a8,8,0,0,0-8,8v40a16,16,0,0,1-16,16H48a16,16,0,0,1-16-16V115.55a16,16,0,0,1,5.17-11.78l80-75.48.11-.11a16,16,0,0,1,21.53,0,1.14,1.14,0,0,0,.11.11l80,75.48A16,16,0,0,1,224,115.55Z"
                ></path>
              </svg>
            </div>
            <p class="text-[#111518] text-xs font-medium leading-normal tracking-[0.015em]">Home</p>
          </a>
          <a class="just flex flex-1 flex-col items-center justify-end gap-1 text-[#60778a]" href="#">
            <div class="text-[#60778a] flex h-8 items-center justify-center" data-icon="MagnifyingGlass" data-size="24px" data-weight="regular">
              <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                <path d="M229.66,218.34l-50.07-50.06a88.11,88.11,0,1,0-11.31,11.31l50.06,50.07a8,8,0,0,0,11.32-11.32ZM40,112a72,72,0,1,1,72,72A72.08,72.08,0,0,1,40,112Z"></path>
              </svg>
            </div>
            <p class="text-[#60778a] text-xs font-medium leading-normal tracking-[0.015em]">Discover</p>
          </a>
          <a class="just flex flex-1 flex-col items-center justify-end gap-1 text-[#60778a]" href="#">
            <div class="text-[#60778a] flex h-8 items-center justify-center" data-icon="Bookmark" data-size="24px" data-weight="regular">
              <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                <path
                  d="M184,32H72A16,16,0,0,0,56,48V224a8,8,0,0,0,12.24,6.78L128,193.43l59.77,37.35A8,8,0,0,0,200,224V48A16,16,0,0,0,184,32Zm0,16V161.57l-51.77-32.35a8,8,0,0,0-8.48,0L72,161.56V48ZM132.23,177.22a8,8,0,0,0-8.48,0L72,209.57V180.43l56-35,56,35v29.14Z"
                ></path>
              </svg>
            </div>
            <p class="text-[#60778a] text-xs font-medium leading-normal tracking-[0.015em]">Favorites</p>
          </a>
          <a class="just flex flex-1 flex-col items-center justify-end gap-1 text-[#60778a]" href="#">
            <div class="text-[#60778a] flex h-8 items-center justify-center" data-icon="User" data-size="24px" data-weight="regular">
              <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                <path
                  d="M230.92,212c-15.23-26.33-38.7-45.21-66.09-54.16a72,72,0,1,0-73.66,0C63.78,166.78,40.31,185.66,25.08,212a8,8,0,1,0,13.85,8c18.84-32.56,52.14-52,89.07-52s70.23,19.44,89.07,52a8,8,0,1,0,13.85-8ZM72,96a56,56,0,1,1,56,56A56.06,56.06,0,0,1,72,96Z"
                ></path>
              </svg>
            </div>
            <p class="text-[#60778a] text-xs font-medium leading-normal tracking-[0.015em]">Profile</p>
          </a>
        </div>
        <div class="h-5 bg-white"></div>
      </div>
    </div>
  </body>
</html>
<html>
  <head>
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="" />
    <link
      rel="stylesheet"
      as="style"
      onload="this.rel='stylesheet'"
      href="https://fonts.googleapis.com/css2?display=swap&amp;family=Noto+Sans%3Awght%40400%3B500%3B700%3B900&amp;family=Plus+Jakarta+Sans%3Awght%40400%3B500%3B700%3B800"
    />

    <title>Galileo Design</title>
    <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64," />

    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  </head>
  <body>
    <div
      class="relative flex size-full min-h-screen flex-col bg-white justify-between group/design-root overflow-x-hidden"
      style='font-family: "Plus Jakarta Sans", "Noto Sans", sans-serif;'
    >
      <div>
        <div class="@container">
          <div class="@[480px]:px-4 @[480px]:py-3">
            <div
              class="w-full bg-center bg-no-repeat bg-cover flex flex-col justify-end overflow-hidden bg-white @[480px]:rounded-xl min-h-[218px]"
              style='background-image: url("https://cdn.usegalileo.ai/sdxl10/cd979ed0-0d73-48a6-98fd-5eedaadc39de.png");'
            ></div>
          </div>
        </div>
        <div class="flex p-4 @container">
          <div class="flex w-full flex-col gap-4 @[520px]:flex-row @[520px]:justify-between">
            <div class="flex gap-4">
              <div
                class="bg-center bg-no-repeat aspect-square bg-cover rounded-xl min-h-32 w-32"
                style='background-image: url("https://cdn.usegalileo.ai/sdxl10/af26201e-8b2a-471d-a679-d816f2bf1efc.png");'
              ></div>
              <div class="flex flex-col">
                <p class="text-[#111518] text-[22px] font-bold leading-tight tracking-[-0.015em]">Summer Concert Series</p>
                <p class="text-[#60778a] text-base font-normal leading-normal">The Venue · Cityville</p>
                <p class="text-[#60778a] text-base font-normal leading-normal">Friday, July 12, 2024</p>
              </div>
            </div>
            <div class="flex w-full max-w-[480px] gap-3 @[480px]:w-auto">
              <button
                class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-10 px-4 bg-[#f0f2f5] text-[#111518] text-sm font-bold leading-normal tracking-[0.015em] flex-1 @[480px]:flex-auto"
              >
                <span class="truncate">Interested</span>
              </button>
              <button
                class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-10 px-4 bg-[#2094f3] text-white text-sm font-bold leading-normal tracking-[0.015em] flex-1 @[480px]:flex-auto"
              >
                <span class="truncate">Get Tickets</span>
              </button>
            </div>
          </div>
        </div>
        <div class="flex items-center gap-4 bg-white px-4 min-h-14">
          <div class="text-[#111518] flex items-center justify-center rounded-lg bg-[#f0f2f5] shrink-0 size-10" data-icon="MapPin" data-size="24px" data-weight="regular">
            <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
              <path
                d="M128,64a40,40,0,1,0,40,40A40,40,0,0,0,128,64Zm0,64a24,24,0,1,1,24-24A24,24,0,0,1,128,128Zm0-112a88.1,88.1,0,0,0-88,88c0,31.4,14.51,64.68,42,96.25a254.19,254.19,0,0,0,41.45,38.3,8,8,0,0,0,9.18,0A254.19,254.19,0,0,0,174,200.25c27.45-31.57,42-64.85,42-96.25A88.1,88.1,0,0,0,128,16Zm0,206c-16.53-13-72-60.75-72-118a72,72,0,0,1,144,0C200,161.23,144.53,209,128,222Z"
              ></path>
            </svg>
          </div>
          <p class="text-[#111518] text-base font-normal leading-normal flex-1 truncate">The Venue</p>
        </div>
        <div class="flex items-center gap-4 bg-white px-4 min-h-14">
          <div class="text-[#111518] flex items-center justify-center rounded-lg bg-[#f0f2f5] shrink-0 size-10" data-icon="Calendar" data-size="24px" data-weight="regular">
            <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
              <path
                d="M208,32H184V24a8,8,0,0,0-16,0v8H88V24a8,8,0,0,0-16,0v8H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM72,48v8a8,8,0,0,0,16,0V48h80v8a8,8,0,0,0,16,0V48h24V80H48V48ZM208,208H48V96H208V208Zm-96-88v64a8,8,0,0,1-16,0V132.94l-4.42,2.22a8,8,0,0,1-7.16-14.32l16-8A8,8,0,0,1,112,120Zm59.16,30.45L152,176h16a8,8,0,0,1,0,16H136a8,8,0,0,1-6.4-12.8l28.78-38.37A8,8,0,1,0,145.07,132a8,8,0,1,1-13.85-8A24,24,0,0,1,176,136,23.76,23.76,0,0,1,171.16,150.45Z"
              ></path>
            </svg>
          </div>
          <p class="text-[#111518] text-base font-normal leading-normal flex-1 truncate">120 going · 650 interested</p>
        </div>
        <div class="flex items-center gap-4 bg-white px-4 min-h-14">
          <div class="text-[#111518] flex items-center justify-center rounded-lg bg-[#f0f2f5] shrink-0 size-10" data-icon="Ticket" data-size="24px" data-weight="regular">
            <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
              <path
                d="M227.19,104.48A16,16,0,0,0,240,88.81V64a16,16,0,0,0-16-16H32A16,16,0,0,0,16,64V88.81a16,16,0,0,0,12.81,15.67,24,24,0,0,1,0,47A16,16,0,0,0,16,167.19V192a16,16,0,0,0,16,16H224a16,16,0,0,0,16-16V167.19a16,16,0,0,0-12.81-15.67,24,24,0,0,1,0-47ZM32,167.2a40,40,0,0,0,0-78.39V64H88V192H32Zm192,0V192H104V64H224V88.8a40,40,0,0,0,0,78.39Z"
              ></path>
            </svg>
          </div>
          <p class="text-[#111518] text-base font-normal leading-normal flex-1 truncate">Tickets: $30</p>
        </div>
        <h3 class="text-[#111518] text-lg font-bold leading-tight tracking-[-0.015em] px-4 pb-2 pt-4">What to expect</h3>
        <p class="text-[#111518] text-base font-normal leading-normal pb-3 pt-1 px-4">
          Friday, July 12. The Venue presents the Summer Concert Series featuring local indie bands. All ages event. Doors open at 6PM.
        </p>
        <h2 class="text-[#111518] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">About the Venue</h2>
        <div class="flex px-4 py-3">
          <div
            class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl object-cover"
            style='background-image: url("https://cdn.usegalileo.ai/maps/6dad2e06-3b1c-4d41-a39d-e6964ec0439f.png");'
          ></div>
        </div>
        <div class="flex items-center gap-4 bg-white px-4 min-h-14">
          <div class="text-[#111518] flex items-center justify-center rounded-lg bg-[#f0f2f5] shrink-0 size-10" data-icon="Compass" data-size="24px" data-weight="regular">
            <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
              <path
                d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216ZM172.42,72.84l-64,32a8.05,8.05,0,0,0-3.58,3.58l-32,64A8,8,0,0,0,80,184a8.1,8.1,0,0,0,3.58-.84l64-32a8.05,8.05,0,0,0,3.58-3.58l32-64a8,8,0,0,0-10.74-10.74ZM138,138,97.89,158.11,118,118l40.15-20.07Z"
              ></path>
            </svg>
          </div>
          <p class="text-[#111518] text-base font-normal leading-normal flex-1 truncate">123 Main Street, Cityville</p>
        </div>
        <div class="flex items-center gap-4 bg-white px-4 min-h-14">
          <div class="text-[#111518] flex items-center justify-center rounded-lg bg-[#f0f2f5] shrink-0 size-10" data-icon="Car" data-size="24px" data-weight="regular">
            <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
              <path
                d="M240,112H229.2L201.42,49.5A16,16,0,0,0,186.8,40H69.2a16,16,0,0,0-14.62,9.5L26.8,112H16a8,8,0,0,0,0,16h8v80a16,16,0,0,0,16,16H64a16,16,0,0,0,16-16V192h96v16a16,16,0,0,0,16,16h24a16,16,0,0,0,16-16V128h8a8,8,0,0,0,0-16ZM69.2,56H186.8l24.89,56H44.31ZM64,208H40V192H64Zm128,0V192h24v16Zm24-32H40V128H216ZM56,152a8,8,0,0,1,8-8H80a8,8,0,0,1,0,16H64A8,8,0,0,1,56,152Zm112,0a8,8,0,0,1,8-8h16a8,8,0,0,1,0,16H176A8,8,0,0,1,168,152Z"
              ></path>
            </svg>
          </div>
          <p class="text-[#111518] text-base font-normal leading-normal flex-1 truncate">Ample parking available</p>
        </div>
      </div>
      <div>
        <div class="flex gap-2 border-t border-[#f0f2f5] bg-white px-4 pb-3 pt-2">
          <a class="just flex flex-1 flex-col items-center justify-end gap-1 rounded-full text-[#111518]" href="#">
            <div class="text-[#111518] flex h-8 items-center justify-center" data-icon="House" data-size="24px" data-weight="fill">
              <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                <path
                  d="M224,115.55V208a16,16,0,0,1-16,16H168a16,16,0,0,1-16-16V168a8,8,0,0,0-8-8H112a8,8,0,0,0-8,8v40a16,16,0,0,1-16,16H48a16,16,0,0,1-16-16V115.55a16,16,0,0,1,5.17-11.78l80-75.48.11-.11a16,16,0,0,1,21.53,0,1.14,1.14,0,0,0,.11.11l80,75.48A16,16,0,0,1,224,115.55Z"
                ></path>
              </svg>
            </div>
            <p class="text-[#111518] text-xs font-medium leading-normal tracking-[0.015em]">Home</p>
          </a>
          <a class="just flex flex-1 flex-col items-center justify-end gap-1 text-[#60778a]" href="#">
            <div class="text-[#60778a] flex h-8 items-center justify-center" data-icon="Users" data-size="24px" data-weight="regular">
              <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                <path
                  d="M117.25,157.92a60,60,0,1,0-66.5,0A95.83,95.83,0,0,0,3.53,195.63a8,8,0,1,0,13.4,8.74,80,80,0,0,1,134.14,0,8,8,0,0,0,13.4-8.74A95.83,95.83,0,0,0,117.25,157.92ZM40,108a44,44,0,1,1,44,44A44.05,44.05,0,0,1,40,108Zm210.14,98.7a8,8,0,0,1-11.07-2.33A79.83,79.83,0,0,0,172,168a8,8,0,0,1,0-16,44,44,0,1,0-16.34-84.87,8,8,0,1,1-5.94-14.85,60,60,0,0,1,55.53,105.64,95.83,95.83,0,0,1,47.22,37.71A8,8,0,0,1,250.14,206.7Z"
                ></path>
              </svg>
            </div>
            <p class="text-[#60778a] text-xs font-medium leading-normal tracking-[0.015em]">Friends</p>
          </a>
          <a class="just flex flex-1 flex-col items-center justify-end gap-1 text-[#60778a]" href="#">
            <div class="text-[#60778a] flex h-8 items-center justify-center" data-icon="Video" data-size="24px" data-weight="regular">
              <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                <path
                  d="M164.44,105.34l-48-32A8,8,0,0,0,104,80v64a8,8,0,0,0,12.44,6.66l48-32a8,8,0,0,0,0-13.32ZM120,129.05V95l25.58,17ZM216,40H40A16,16,0,0,0,24,56V168a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40Zm0,128H40V56H216V168Zm16,40a8,8,0,0,1-8,8H32a8,8,0,0,1,0-16H224A8,8,0,0,1,232,208Z"
                ></path>
              </svg>
            </div>
            <p class="text-[#60778a] text-xs font-medium leading-normal tracking-[0.015em]">Video</p>
          </a>
          <a class="just flex flex-1 flex-col items-center justify-end gap-1 text-[#60778a]" href="#">
            <div class="text-[#60778a] flex h-8 items-center justify-center" data-icon="Bell" data-size="24px" data-weight="regular">
              <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                <path
                  d="M221.8,175.94C216.25,166.38,208,139.33,208,104a80,80,0,1,0-160,0c0,35.34-8.26,62.38-13.81,71.94A16,16,0,0,0,48,200H88.81a40,40,0,0,0,78.38,0H208a16,16,0,0,0,13.8-24.06ZM128,216a24,24,0,0,1-22.62-16h45.24A24,24,0,0,1,128,216ZM48,184c7.7-13.24,16-43.92,16-80a64,64,0,1,1,128,0c0,36.05,8.28,66.73,16,80Z"
                ></path>
              </svg>
            </div>
            <p class="text-[#60778a] text-xs font-medium leading-normal tracking-[0.015em]">Notifications</p>
          </a>
          <a class="just flex flex-1 flex-col items-center justify-end gap-1 text-[#60778a]" href="#">
            <div class="text-[#60778a] flex h-8 items-center justify-center" data-icon="User" data-size="24px" data-weight="regular">
              <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                <path
                  d="M230.92,212c-15.23-26.33-38.7-45.21-66.09-54.16a72,72,0,1,0-73.66,0C63.78,166.78,40.31,185.66,25.08,212a8,8,0,1,0,13.85,8c18.84-32.56,52.14-52,89.07-52s70.23,19.44,89.07,52a8,8,0,1,0,13.85-8ZM72,96a56,56,0,1,1,56,56A56.06,56.06,0,0,1,72,96Z"
                ></path>
              </svg>
            </div>
            <p class="text-[#60778a] text-xs font-medium leading-normal tracking-[0.015em]">Profile</p>
          </a>
        </div>
        <div class="h-5 bg-white"></div>
      </div>
    </div>
  </body>
</html>
<html>
  <head>
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="" />
    <link
      rel="stylesheet"
      as="style"
      onload="this.rel='stylesheet'"
      href="https://fonts.googleapis.com/css2?display=swap&amp;family=Noto+Sans%3Awght%40400%3B500%3B700%3B900&amp;family=Plus+Jakarta+Sans%3Awght%40400%3B500%3B700%3B800"
    />

    <title>Galileo Design</title>
    <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64," />

    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  </head>
  <body>
    <div
      class="relative flex size-full min-h-screen flex-col bg-white justify-between group/design-root overflow-x-hidden"
      style='font-family: "Plus Jakarta Sans", "Noto Sans", sans-serif;'
    >
      <div>
        <div class="flex items-center bg-white p-4 pb-2 justify-between">
          <div class="text-[#111518] flex size-12 shrink-0 items-center" data-icon="ArrowLeft" data-size="24px" data-weight="regular">
            <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
              <path d="M224,128a8,8,0,0,1-8,8H59.31l58.35,58.34a8,8,0,0,1-11.32,11.32l-72-72a8,8,0,0,1,0-11.32l72-72a8,8,0,0,1,11.32,11.32L59.31,120H216A8,8,0,0,1,224,128Z"></path>
            </svg>
          </div>
          <h2 class="text-[#111518] text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center pr-12">Rate Venues</h2>
        </div>
        <h3 class="text-[#111518] text-lg font-bold leading-tight tracking-[-0.015em] px-4 pb-2 pt-4">Have you been there recently?</h3>
        <div class="p-4 @container">
          <div class="flex flex-col items-stretch justify-start rounded-xl @xl:flex-row @xl:items-start">
            <div
              class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl"
              style='background-image: url("https://cdn.usegalileo.ai/sdxl10/4df96e75-be36-4585-81fb-8585eec00bb3.png");'
            ></div>
            <div class="flex w-full min-w-72 grow flex-col items-stretch justify-center gap-1 py-4 @xl:px-4">
              <p class="text-[#111518] text-lg font-bold leading-tight tracking-[-0.015em]">Electric Beats</p>
              <div class="flex items-end gap-3 justify-between">
                <p class="text-[#60778a] text-base font-normal leading-normal">The dance floor was electrifying! — 2 weeks ago</p>
                <button
                  class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-8 px-4 bg-[#2094f3] text-white text-sm font-medium leading-normal"
                >
                  <span class="truncate">Rate</span>
                </button>
              </div>
            </div>
          </div>
        </div>
        <div class="p-4 @container">
          <div class="flex flex-col items-stretch justify-start rounded-xl @xl:flex-row @xl:items-start">
            <div
              class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl"
              style='background-image: url("https://cdn.usegalileo.ai/sdxl10/c8775c77-f3ad-4e5e-8766-3e8a8306b647.png");'
            ></div>
            <div class="flex w-full min-w-72 grow flex-col items-stretch justify-center gap-1 py-4 @xl:px-4">
              <p class="text-[#111518] text-lg font-bold leading-tight tracking-[-0.015em]">A Night at the Opera</p>
              <div class="flex items-end gap-3 justify-between">
                <p class="text-[#60778a] text-base font-normal leading-normal">The performance was moving. — 3 weeks ago</p>
                <button
                  class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-8 px-4 bg-[#2094f3] text-white text-sm font-medium leading-normal"
                >
                  <span class="truncate">Rate</span>
                </button>
              </div>
            </div>
          </div>
        </div>
        <div class="p-4 @container">
          <div class="flex flex-col items-stretch justify-start rounded-xl @xl:flex-row @xl:items-start">
            <div
              class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-xl"
              style='background-image: url("https://cdn.usegalileo.ai/sdxl10/26a08431-d65b-48b6-aad2-8f7038792c22.png");'
            ></div>
            <div class="flex w-full min-w-72 grow flex-col items-stretch justify-center gap-1 py-4 @xl:px-4">
              <p class="text-[#111518] text-lg font-bold leading-tight tracking-[-0.015em]">Blues &amp; BBQ</p>
              <div class="flex items-end gap-3 justify-between">
                <p class="text-[#60778a] text-base font-normal leading-normal">The food was smokin', and the music soulful. — 1 month ago</p>
                <button
                  class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-8 px-4 bg-[#2094f3] text-white text-sm font-medium leading-normal"
                >
                  <span class="truncate">Rate</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div>
        <div class="flex gap-2 border-t border-[#f0f2f5] bg-white px-4 pb-3 pt-2">
          <a class="just flex flex-1 flex-col items-center justify-end gap-1 text-[#60778a]" href="#">
            <div class="text-[#60778a] flex h-8 items-center justify-center" data-icon="House" data-size="24px" data-weight="regular">
              <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                <path
                  d="M218.83,103.77l-80-75.48a1.14,1.14,0,0,1-.11-.11,16,16,0,0,0-21.53,0l-.11.11L37.17,103.77A16,16,0,0,0,32,115.55V208a16,16,0,0,0,16,16H96a16,16,0,0,0,16-16V160h32v48a16,16,0,0,0,16,16h48a16,16,0,0,0,16-16V115.55A16,16,0,0,0,218.83,103.77ZM208,208H160V160a16,16,0,0,0-16-16H112a16,16,0,0,0-16,16v48H48V115.55l.11-.1L128,40l79.9,75.43.11.1Z"
                ></path>
              </svg>
            </div>
            <p class="text-[#60778a] text-xs font-medium leading-normal tracking-[0.015em]">Home</p>
          </a>
          <a class="just flex flex-1 flex-col items-center justify-end gap-1 rounded-full text-[#111518]" href="#">
            <div class="text-[#111518] flex h-8 items-center justify-center" data-icon="MagnifyingGlass" data-size="24px" data-weight="fill">
              <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                <path
                  d="M168,112a56,56,0,1,1-56-56A56,56,0,0,1,168,112Zm61.66,117.66a8,8,0,0,1-11.32,0l-50.06-50.07a88,88,0,1,1,11.32-11.31l50.06,50.06A8,8,0,0,1,229.66,229.66ZM112,184a72,72,0,1,0-72-72A72.08,72.08,0,0,0,112,184Z"
                ></path>
              </svg>
            </div>
            <p class="text-[#111518] text-xs font-medium leading-normal tracking-[0.015em]">Explore</p>
          </a>
          <a class="just flex flex-1 flex-col items-center justify-end gap-1 text-[#60778a]" href="#">
            <div class="text-[#60778a] flex h-8 items-center justify-center" data-icon="PlusSquare" data-size="24px" data-weight="regular">
              <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                <path
                  d="M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32Zm0,176H48V48H208V208Zm-32-80a8,8,0,0,1-8,8H136v32a8,8,0,0,1-16,0V136H88a8,8,0,0,1,0-16h32V88a8,8,0,0,1,16,0v32h32A8,8,0,0,1,176,128Z"
                ></path>
              </svg>
            </div>
            <p class="text-[#60778a] text-xs font-medium leading-normal tracking-[0.015em]">Post</p>
          </a>
          <a class="just flex flex-1 flex-col items-center justify-end gap-1 text-[#60778a]" href="#">
            <div class="text-[#60778a] flex h-8 items-center justify-center" data-icon="Tray" data-size="24px" data-weight="regular">
              <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                <path
                  d="M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32Zm0,16V152h-28.7A15.86,15.86,0,0,0,168,156.69L148.69,176H107.31L88,156.69A15.86,15.86,0,0,0,76.69,152H48V48Zm0,160H48V168H76.69L96,187.31A15.86,15.86,0,0,0,107.31,192h41.38A15.86,15.86,0,0,0,160,187.31L179.31,168H208v40Z"
                ></path>
              </svg>
            </div>
            <p class="text-[#60778a] text-xs font-medium leading-normal tracking-[0.015em]">Inbox</p>
          </a>
          <a class="just flex flex-1 flex-col items-center justify-end gap-1 text-[#60778a]" href="#">
            <div class="text-[#60778a] flex h-8 items-center justify-center" data-icon="User" data-size="24px" data-weight="regular">
              <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" viewBox="0 0 256 256">
                <path
                  d="M230.92,212c-15.23-26.33-38.7-45.21-66.09-54.16a72,72,0,1,0-73.66,0C63.78,166.78,40.31,185.66,25.08,212a8,8,0,1,0,13.85,8c18.84-32.56,52.14-52,89.07-52s70.23,19.44,89.07,52a8,8,0,1,0,13.85-8ZM72,96a56,56,0,1,1,56,56A56.06,56.06,0,0,1,72,96Z"
                ></path>
              </svg>
            </div>
            <p class="text-[#60778a] text-xs font-medium leading-normal tracking-[0.015em]">Profile</p>
          </a>
        </div>
        <div class="h-5 bg-white"></div>
      </div>
    </div>
  </body>
</html>
