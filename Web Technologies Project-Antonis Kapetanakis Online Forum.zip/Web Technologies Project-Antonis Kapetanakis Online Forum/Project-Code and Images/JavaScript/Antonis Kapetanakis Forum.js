<!DOCTYPE html>
<head>
<title>JavaScriptCode</title>
//This is the whole JavaScript code from the main and all the additional pages//
<script src="myscripts.js"></script>
<script>
<body>
<meta charset="UTF-8"
<a href="About.html">About</a>
<a href="Contact.html">Contact</a>
<a href="Article 1.html">Article 1</a>
<a href="Article 2.html">Article 2</a>
<a href="Inbox.html">Inbox</a>
<a href="Tech News.html">Tech news</a>
<a href="Twitter Page.html">Twitter page</a>
<a href="Facebook Page.html">Facebook page</a>
<a href="Linkedin Page.html">Linkedin page</a>
<a href="My Forum.html">My Forum</a>
<a href="index.html">Home</a>

<script>
<body>

function showDisagree() {
var text = document.getElementById("hidden-disagree");
text.style.display = "block";
}

function showText() {
document.getElementById("output").style.display = "block";
}

function showAgree() {
var text = document.getElementById("hidden-agree");
text.style.display = "block";
}

function showText() {
document.getElementById("output").style.display = "block";
}

function showAgree() {
var text = document.getElementById("hidden-agree");
text.style.display = "block";
}
function showDisagree() {
var text = document.getElementById("hidden-disagree");
text.style.display = "block";
}

function showAgree() {
var text = document.getElementById("hidden-agree");
text.style.display = "block";
}
function showDisagree() {
var text = document.getElementById("hidden-disagree");
text.style.display = "block";
}

var modal = document.getElementById('id01');
window.onclick = function(event) {
if (event.target == modal) {
modal.style.display = "none";
}
}

document.addEventListener(
"click",
function(event) {
var target = event.target;
var replyForm;
if (target.matches("[data-toggle='reply-form']")) {
replyForm = document.getElementById(target.getAttribute("data-target"));
replyForm.classList.toggle("d-none");
}
},
false
);

function displayText() {
document.getElementById("text").innerHTML = "Your Post has been uploaded!";
		
}

let slideIndex = 0;
let timeoutId = null;
const slides = document.getElementsByClassName("mySlides");
const dots = document.getElementsByClassName("dot");
      
showSlides();
function currentSlide(index) {
slideIndex = index;
showSlides();
}
function plusSlides(step) {
        
if(step < 0) {
slideIndex -= 2;
            
if(slideIndex < 0) {
slideIndex = slides.length - 1;
}
}
        
showSlides(6);
}
function showSlides() {
for(let i = 0; i < slides.length; i++) {
slides[i].style.display = "none";
 dots[i].classList.remove('active');
}
slideIndex++;
if(slideIndex > slides.length) {
slideIndex = 1
}
slides[slideIndex - 1].style.display = "block";
dots[slideIndex - 1].classList.add('active');
if(timeoutId) {
clearTimeout(timeoutId);
}
timeoutId = setTimeout(showSlides, 5000); 
}

script type="text/javascript">
function googleTranslateElementInit() {
 new google.translate.TranslateElement({
pageLanguage: 'en', layout: 
google.translate.TranslateElement.InlineLayout.HORIZONTAL, autoDisplay: 
false, includedLanguages: 'fr,de,es,', gaTrack: true, gaId: 'YOUR_API_KEY'
}, 'google_translate_element');
}
</body>
</script>