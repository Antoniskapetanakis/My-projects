-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2024 at 10:05 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `release_date` date DEFAULT NULL,
  `genre` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `available` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_id`, `title`, `author`, `release_date`, `genre`, `image_url`, `available`) VALUES
(2, 'Moby-Dick', 'Herman Melville', '1851-10-18', 'Adventure', 'https://m.media-amazon.com/images/I/616R20nvohL._AC_UF1000,1000_QL80_.jpg', 1),
(3, 'The Catcher in the Rye', 'J.D. Salinger', '1951-07-16', 'Fiction', 'https://external.webstorage.gr/mmimages/image/27/69/24/85/1333058-264x264-800x800-96x96-560x560.jpg', 1),
(4, 'Lord of the Flies', 'William Golding', '1954-09-17', 'Fiction', 'https://external.webstorage.gr/mmimages/image/34/81/75/1/9780571371723-560x560.jpg', 1),
(5, 'Brave New World', 'Aldous Huxley', '1932-10-07', 'Dystopian', 'https://external.webstorage.gr/mmimages/image/97/82/23/5/0414458-264x264-800x800-96x96-560x560.jpg', 1),
(6, 'The Hobbit', 'J.R.R. Tolkien', '1937-09-21', 'Fantasy', 'https://external.webstorage.gr/mmimages/image/17/12/18/42/0615136-264x264-800x800-96x96-560x560.jpg', 1),
(7, 'Fahrenheit 451', 'Ray Bradbury', '1953-10-19', 'Dystopian', 'https://external.webstorage.gr/mmimages/image/50/83/94/16/0694166-264x264-800x800-96x96-560x560.jpg', 1),
(8, 'Animal Farm', 'George Orwell', '1945-08-17', 'Satire', 'https://external.webstorage.gr/mmimages/image/35/32/86/53/9781781129692-560x560.jpg', 1),
(9, 'The Grapes of Wrath', 'John Steinbeck', '1939-04-14', 'Fiction', 'https://external.webstorage.gr/mmimages/image/48/55/29/80/1324979-264x264-800x800-96x96-560x560.jpg', 1),
(10, 'Wuthering Heights', 'Emily Brontë', '1847-12-14', 'Gothic Fiction', 'https://external.webstorage.gr/mmimages/image/71/0/6/8/1445333-264x264-800x800-96x96-560x560.jpg', 1),
(11, 'Frankenstein', 'Mary Shelley', '1818-01-01', 'Gothic', 'https://external.webstorage.gr/mmimages/image/32/24/57/58/1771657-BOOK-hero-560x560.jpg', 1),
(12, 'Dracula', 'Bram Stoker', '1897-05-26', 'Gothic Horror', 'https://external.webstorage.gr/mmimages/image/93/33/18/63/1167496-264x264-800x800-96x96-560x560.jpg', 1),
(13, 'The Picture of Dorian Gray', 'Oscar Wilde', '1890-07-20', 'Gothic Fiction', 'https://external.webstorage.gr/mmimages/image/81/26/66/32/0839599-264x264-800x800-96x96-560x560.jpg', 1),
(14, 'The Odyssey', 'Homer', '0000-00-00', 'Epic Poetry', 'https://libris.to/media/jacket/19735551_illustrated-odyssey.jpg', 1),
(15, 'War and Peace', 'Leo Tolstoy', '1869-01-01', 'Historical Fiction', 'https://external.webstorage.gr/mmimages/image/23/0/33/77/9780199232765-560x560.jpg', 1),
(16, 'The Adventures of Huckleberry Finn', 'Mark Twain', '1884-12-10', 'Adventure', 'https://external.webstorage.gr/mmimages/image/59/98/19/6/1014003-264x264-800x800-96x96-560x560.jpg', 1),
(17, 'One Hundred Years of Solitude', 'Mark Twain', '1948-04-23', 'Drama', 'https://external.webstorage.gr/mmimages/image/21/41/13/53/0811432-264x264-800x800-96x96-560x560.jpg', 1),
(18, 'The Alchemist', 'Paulo Coelho', '1988-05-01', 'Fiction', 'https://external.webstorage.gr/mmimages/image/96/99/43/40/0000900-264x264-800x800-96x96-560x560.jpg', 1),
(19, 'The Lord of the Rings', 'J.R.R. Tolkien', '1954-07-29', 'Fantasy', 'https://external.webstorage.gr/mmimages/image/79/35/89/73/0413408-264x264-800x800-96x96-560x560.jpg', 1),
(20, 'Harry Potter and the Philosopher\'s Stone', 'J.K. Rowling', '1997-06-26', 'Fantasy', 'https://external.webstorage.gr/mmimages/image/21/31/74/21/0849407-264x264-800x800-96x96-560x560.jpg', 1),
(21, 'Divergent', 'Veronica Roth', '2024-04-26', 'Science Fiction', 'https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/7d71f413323579.5627284a91785.jpg', 1),
(22, 'Cinderella', 'Charles Perrault', '1697-12-13', 'Family', 'https://m.media-amazon.com/images/I/71+oWUCyr0L._AC_UF1000,1000_QL80_DpWeblab_.jpg', 1),
(23, 'Homage to Catalonia', 'George Orwell', '1938-04-25', 'Social', 'https://external.webstorage.gr/mmimages/image/20/54/74/36/0763355-264x264-800x800-96x96-560x560.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `borrowedbooks`
--

CREATE TABLE `borrowedbooks` (
  `book_id` int(11) NOT NULL,
  `book_title` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `return_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `borrowedbooks`
--

INSERT INTO `borrowedbooks` (`book_id`, `book_title`, `user_id`, `username`, `return_date`) VALUES
(22, 'Cinderella', 4, 'emily_davis', '2024-04-26');

-- --------------------------------------------------------

--
-- Table structure for table `officials`
--

CREATE TABLE `officials` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `officials`
--

INSERT INTO `officials` (`id`, `name`, `password`, `salary`) VALUES
(1, 'Johny Knox', 'password123', 70000.00),
(2, 'Janet Smithin', 'password123', 80000.00),
(3, 'Michael Johnson', 'password123', 60000.00),
(4, 'Emilia Brownie', 'password123', 65000.00),
(5, 'David Lynch', 'password123', 75000.00);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`) VALUES
(1, 'john_doe', 'common_password', 'john_doe@example.com'),
(3, 'mike_jones', 'common_password', 'mike_jones@example.com'),
(4, 'emily_davis', 'common_password', 'emily_davis@example.com'),
(5, 'chris_wilson', 'common_password', 'chris_wilson@example.com'),
(6, 'amanda_brown', 'common_password', 'amanda_brown@example.com'),
(7, 'kevin_taylor', 'common_password', 'kevin_taylor@example.com'),
(8, 'sarah_clark', 'common_password', 'sarah_clark@example.com'),
(9, 'matt_white', 'common_password', 'matt_white@example.com'),
(10, 'laura_martin', 'common_password', 'laura_martin@example.com'),
(11, 'ryan_thompson', 'common_password', 'ryan_thompson@example.com'),
(12, 'jessica_hall', 'common_password', 'jessica_hall@example.com'),
(13, 'david_anderson', 'common_password', 'david_anderson@example.com'),
(14, 'ashley_miller', 'common_password', 'ashley_miller@example.com'),
(15, 'jason_wilson', 'common_password', 'jason_wilson@example.com'),
(16, 'amy_jackson', 'common_password', 'amy_jackson@example.com'),
(17, 'brian_moore', 'common_password', 'newemail@example.com'),
(18, 'samantha_adams', 'common_password', 'samantha_adams@example.com'),
(19, 'alex_garcia', 'common_password', 'newemail@example.com'),
(20, 'olivia_rodriguez', 'common_password', 'olivia_rodriguez@example.com'),
(21, 'admin', 'common_password', 'admin@example.com'),
(22, 'giannis_sigma', 'common_password', 'giannis@example.com'),
(25, 'giannis_trape', '12345', 'trape@example.com'),
(26, 'meli_petra', '12345', 'petra@example.com'),
(27, 'antonis', '12345678910', 'antonis@example.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `borrowedbooks`
--
ALTER TABLE `borrowedbooks`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `officials`
--
ALTER TABLE `officials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `officials`
--
ALTER TABLE `officials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
