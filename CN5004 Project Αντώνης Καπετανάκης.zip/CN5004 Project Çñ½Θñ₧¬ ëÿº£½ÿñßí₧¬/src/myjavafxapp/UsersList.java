package myjavafxapp;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;

public class UsersList {
    private static final String url = "jdbc:mysql://localhost:3306/library_database";
    private static final String username = "root";
    private static final String password = "";

    private ListView<User> listView; // Define listView variable
    private boolean isOfficial;

    public void displayUsers(Stage primaryStage) {
        // Create menu bar
        MenuBar menuBar = new MenuBar();
        Menu menu = new Menu("File");
        MenuItem exitMenuItem = new MenuItem("Exit");
        exitMenuItem.setOnAction(event -> primaryStage.close());
        menu.getItems().add(exitMenuItem);
        menuBar.getMenus().add(menu);

        listView = new ListView<>(); // Initialize listView
        listView.setCellFactory(param -> new UserListViewCell());

        VBox root = new VBox(10);
        root.setPadding(new Insets(10));
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-background-color: #f0f0f0;"); // Set background color

        root.getChildren().addAll(menuBar, new Label("Users List"), listView);

        // Fetch users from the database and populate the ListView
        List<User> users = fetchUsers();
        listView.getItems().addAll(users);

        Button homeButton = new Button("Home");
        homeButton.setOnAction(event -> {
            if (isOfficial) {
                Contact.display(primaryStage, username);
            } else {
                of_mainwindow.display(primaryStage, username);
            }
        }); // Add "Home" button to VBox

        // Apply styles to the home button
        homeButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-weight: bold;");

        root.getChildren().add(homeButton);

        // Add "Home" button to HBox
        HBox buttonContainer = new HBox(homeButton);
        buttonContainer.setAlignment(Pos.CENTER);
        root.getChildren().add(buttonContainer);

        Scene scene = new Scene(root, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Users List");
        primaryStage.show();
    }

    private List<User> fetchUsers() {
        List<User> userList = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String query = "SELECT * FROM users ORDER BY username";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String username = resultSet.getString("username");
                String email = resultSet.getString("email");
                String password = resultSet.getString("password");
                User user = new User(username, email, password);
                userList.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return userList;
    }

    public static class User {
        private String username;
        private String email;
        private String password;

        public User(String username, String email, String password) {
            this.username = username;
            this.email = email;
            this.password = password;
        }

        public String getUsername() {
            return username;
        }

        public String getEmail() {
            return email;
        }

        public String getPassword() {
            return password;
        }

        public String toFormattedString() {
            return "Username: " + username + "\nEmail: " + email + "\nPassword: " + password;
        }
    }

    private class UserListViewCell extends javafx.scene.control.ListCell<User> {
        @Override
        public void updateItem(User user, boolean empty) {
            super.updateItem(user, empty);
            if (empty || user == null) {
                setText(null);
                setGraphic(null);
            } else {
                HBox hbox = new HBox(10);
                Label label = new Label(user.toFormattedString());
                Button removeButton = new Button("Remove");
                Button updateButton = new Button("Update");
                hbox.getChildren().addAll(label, removeButton, updateButton);
                removeButton.setOnAction(event -> removeUser(user));
                updateButton.setOnAction(event -> updateUser(user));
                setGraphic(hbox);
            }
        }
    }

    private void removeUser(User user) {
        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String query = "DELETE FROM users WHERE username = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, user.getUsername());
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("User removed: " + user.getUsername());
                refreshListView();
            } else {
                System.out.println("Failed to remove user: " + user.getUsername());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateUser(User user) {
        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String query = "UPDATE users SET email = ? WHERE username = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, "newemail@example.com");
            statement.setString(2, user.getUsername());
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("User updated: " + user.getUsername());
                refreshListView();
            } else {
                System.out.println("Failed to update user: " + user.getUsername());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void refreshListView() {
        Stage stage = (Stage) listView.getScene().getWindow();
        displayUsers(stage);
    }
}
