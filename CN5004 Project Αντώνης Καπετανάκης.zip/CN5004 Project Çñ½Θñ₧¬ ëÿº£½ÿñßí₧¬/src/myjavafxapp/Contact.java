package myjavafxapp;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Contact {
    public static void display() {
    
        Stage contactStage = new Stage();
        contactStage.setTitle("Contact Form");
        
        Label nameLabel = new Label("Username:");
        Label emailLabel = new Label("Email:");
        Label messageLabel = new Label("Message:");
    

        TextArea nameTextField = new TextArea();
        nameTextField.setPrefRowCount(1); 
        nameTextField.setPrefColumnCount(30); 

        TextArea emailTextField = new TextArea();
        emailTextField.setPrefRowCount(1); 
        emailTextField.setPrefColumnCount(30); 

        TextArea messageTextArea = new TextArea();
        messageTextArea.setPrefRowCount(5);


        Button submitButton = new Button("Submit");
        submitButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 14px;");
        submitButton.setOnAction(event -> {

            System.out.println("Submitted!");
            
        });

          
        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(20));
        vbox.setAlignment(Pos.CENTER);

        GridPane gridPane = new GridPane();
        gridPane.setVgap(10);
        gridPane.setHgap(10);

        gridPane.add(nameLabel, 0, 0);
        gridPane.add(nameTextField, 1, 0);
        gridPane.add(emailLabel, 0, 1);
        gridPane.add(emailTextField, 1, 1);
        gridPane.add(messageLabel, 0, 2);
        gridPane.add(messageTextArea, 1, 2);

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.getChildren().add(submitButton);

        vbox.getChildren().addAll(gridPane, buttonBox);
 Button homeButton = new Button("Home");
        homeButton.setOnAction(event -> MainWindow.display());

        // Add "Home" button to VBox
        vbox.getChildren().add(homeButton);
        Scene scene = new Scene(vbox, 400, 250);
        contactStage.setScene(scene);
        contactStage.show();
    }

    static void display(Stage primaryStage, String username) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
