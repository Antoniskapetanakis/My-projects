package myjavafxapp;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class About {
    public static void display() { 

        Stage aboutStage = new Stage();
        aboutStage.setTitle("About");

        // Text area with information about the system
        TextArea aboutTextArea = new TextArea();
        aboutTextArea.setEditable(false);
        aboutTextArea.setWrapText(true);
        aboutTextArea.setStyle("-fx-font-size: 14px;");

        aboutTextArea.setText("This is a Library Management System. It allows users to search for books, loan books to the library, "
                + "issue and return books.\n\n"
                + "You can find us at:\n"
                + "Address: Stadiou 17\n"
                + "Phone Number: 2810-23456789\n"
                + "Email Address: library@gmail.com");
       
        // Create a layout for the About window
        VBox layout = new VBox(20); 
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);
        layout.setBackground(new Background(new BackgroundFill(Color.WHITE, null, null)));

        Label titleLabel = new Label("About the Library Management System");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        titleLabel.setTextFill(Color.DARKBLUE);

        // Apply CSS styling to the title label
        titleLabel.setStyle("-fx-background-color: #f0f8ff; -fx-padding: 10px;");

        layout.getChildren().addAll(titleLabel, aboutTextArea);
        
        Button homeButton = new Button("Home");
        homeButton.setOnAction(event -> MainWindow.display());

        // Apply CSS styling to the home button
        homeButton.setStyle("-fx-background-color: #4169e1; -fx-text-fill: white; -fx-font-size: 16px; -fx-padding: 10px; -fx-border-radius: 5px;");

        layout.getChildren().add(homeButton);

        Scene scene = new Scene(layout, 600, 400); 

        aboutStage.setScene(scene);
        aboutStage.show();
    }
}
