package myjavafxapp;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LoanBook {

    public static void display() {

        Stage loanBookStage = new Stage();
        loanBookStage.setTitle("Loan Book");

        // Create ListView to display books and images
        ListView<VBox> listView = new ListView<>();

        // Text fields for user ID, book title, return date, and username
        TextField userIdField = new TextField();
        userIdField.setPromptText("Enter User ID");
        TextField bookTitleField = new TextField();
        bookTitleField.setPromptText("Enter Book Title");
        TextField bookIdField = new TextField();
        bookIdField.setPromptText("Enter Book ID");
        TextField returnDateField = new TextField();
        returnDateField.setPromptText("Enter Return Date (YYYY-MM-DD)");
        TextField usernameField = new TextField();
        usernameField.setPromptText("Enter Username");

        Button loanButton = new Button("Loan Selected Book");
        loanButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");

        // Search bar for filtering books
        TextField searchField = new TextField();
        searchField.setPromptText("Search Books");

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-background-color: #f0f0f0;");

        // Add padding to text fields
        userIdField.setStyle("-fx-padding: 5px;");
        bookTitleField.setStyle("-fx-padding: 5px;");
        bookIdField.setStyle("-fx-padding: 5px;");
        returnDateField.setStyle("-fx-padding: 5px;");
        usernameField.setStyle("-fx-padding: 5px;");

        // Add padding and background color to search field
        searchField.setStyle("-fx-padding: 5px; -fx-background-color: #ffffff;");

        // Add padding and background color to loan button
        loanButton.setStyle("-fx-padding: 10px; -fx-background-color: #4CAF50; -fx-text-fill: white;");

        loanButton.setOnAction(event -> {
            VBox selectedBookBox = listView.getSelectionModel().getSelectedItem();
            if (selectedBookBox != null && !userIdField.getText().isEmpty() && !bookTitleField.getText().isEmpty() && !returnDateField.getText().isEmpty() && !usernameField.getText().isEmpty()) {
                Label titleLabel = (Label) selectedBookBox.getChildren().get(0);
                Label idLabel = (Label) selectedBookBox.getChildren().get(4);

                String bookTitle = titleLabel.getText().substring("Title: ".length());
                String bookId = idLabel.getText().substring("ID: ".length());
                String userId = userIdField.getText();
                String returnDate = returnDateField.getText();
                String username = usernameField.getText();

                loanBook(bookTitle, bookId, userId, returnDate, username);
                System.out.println("Book loaned: " + bookTitle);
                loanBookStage.close();
            } else {
                System.out.println("Incomplete information. Please fill in all fields.");
            }
        });

        layout.getChildren().addAll(searchField, listView, userIdField, bookTitleField, bookIdField, returnDateField, usernameField, loanButton);

        Button homeButton = new Button("Home");
        homeButton.setOnAction(event -> MainWindow.display());
        layout.getChildren().add(homeButton);

        // Create BorderPane for overall layout
        BorderPane borderPane = new BorderPane();
        borderPane.setCenter(layout);

        Scene scene = new Scene(borderPane, 600, 600);
        loanBookStage.setScene(scene);
        loanBookStage.show();

        populateBookList(listView);
    }

    private static void populateBookList(ListView<VBox> listView) {
        List<VBox> books = new ArrayList<>();
        try (Connection connection = DatabaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT book_id, title, author, release_date, genre, image_url FROM books");
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                String title = resultSet.getString("title");
                String releaseDate = resultSet.getString("release_date");
                String author = resultSet.getString("author");
                String genre = resultSet.getString("genre");
                String bookId = resultSet.getString("book_id");
                String imageUrl = resultSet.getString("image_url");

                Label titleLabel = new Label("Title: " + title);
                Label authorLabel = new Label("Author: " + author);
                Label genreLabel = new Label("Genre: " + genre);
                Label releaseDateLabel = new Label("Release Date: " + releaseDate);
                Label idLabel = new Label("ID: " + bookId);

                ImageView imageView = new ImageView(new Image(imageUrl));
                imageView.setFitHeight(100);
                imageView.setPreserveRatio(true);

                VBox bookBox = new VBox(5);
                bookBox.getChildren().addAll(titleLabel, authorLabel, genreLabel, releaseDateLabel, idLabel, imageView);

                books.add(bookBox);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        listView.getItems().addAll(books);
    }

    private static void loanBook(String selectedBook, String bookId, String userId, String returnDate, String username) {
        try (Connection connection = DatabaseManager.getConnection()) {
            // Check if the book is already loaned
            boolean isBookLoaned = isBookLoaned(connection, bookId);

            if (isBookLoaned) {
                System.out.println("The book is already loaned by another user.");
                return;
            }

            // If the book is available, insert the loan record into the database
            try (PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO borrowedbooks (book_title, book_id, user_id, username, return_date) VALUES (?, ?, ?, ?, ?)")) {
                statement.setString(1, selectedBook);
                statement.setString(2, bookId);
                statement.setString(3, userId);
                statement.setString(4, username);
                statement.setString(5, returnDate);
                statement.executeUpdate();
                System.out.println("Book loaned: " + selectedBook);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static boolean isBookLoaned(Connection connection, String bookId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT COUNT(*) AS count FROM borrowedbooks WHERE book_id = ?")) {
            statement.setString(1, bookId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int count = resultSet.getInt("count");
                    return count > 0;
                }
            }
        }
        return false;
    }
}
