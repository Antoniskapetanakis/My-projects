package myjavafxapp;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import java.sql.*;

public class Login {
    private static final String url = "jdbc:mysql://localhost:3306/library_database";
    private static final String dbUsername = "root";
    private static final String dbPassword = "";

    public static void display(Stage primaryStage) {

        Stage loginStage = new Stage();
        loginStage.setTitle("Login");

        // Creating labels
        Label titleLabel = new Label("Welcome Back!");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));

        Label usernameLabel = new Label("Username:");
        Label passwordLabel = new Label("Password:");
      

        // Creating text fields
        TextField usernameField = new TextField();
        PasswordField passwordField = new PasswordField();
       

        // Creating buttons
        Button loginButton = new Button("Login");
        loginButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 16px;");
        Button registerButton = new Button("Register");
        registerButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white; -fx-font-size: 16px;");

        // Creating the layout
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20));
        gridPane.setVgap(10);
        gridPane.setHgap(10);

        // Adding components to the layout
        gridPane.add(titleLabel, 0, 0, 2, 1);
        gridPane.add(usernameLabel, 0, 1);
        gridPane.add(usernameField, 1, 1);
        gridPane.add(passwordLabel, 0, 2);
        gridPane.add(passwordField, 1, 2);
        gridPane.add(loginButton, 1, 3);

        // Setting alignment
        gridPane.setAlignment(Pos.CENTER);

        // Setting action for login button
        loginButton.setOnAction(event -> {
            String username = usernameField.getText();
            String password = passwordField.getText();

            boolean isOfficial = isOfficial(username);
            if (authenticateUser(username, password, isOfficial)) {
                loginStage.close();
                MainWindow.display(primaryStage, username, isOfficial);
            } else {
                // Show error message for invalid login
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Invalid username or password");
                alert.showAndWait();
            }
        });
        registerButton.setOnAction(event -> {
            Registration.display();
        });

        // Creating the registration form
        VBox registrationBox = new VBox(10);
        registrationBox.setAlignment(Pos.CENTER);
        registrationBox.getChildren().addAll(new Label("Don't have an account?"), registerButton);

        // Setting background color for better contrast
        gridPane.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, null, null)));

        // Creating the scene
        Scene scene = new Scene(new VBox(20, gridPane, registrationBox), 300, 250);

        // Setting the stage
        loginStage.setScene(scene);
        loginStage.show();
    }

    private static boolean authenticateUser(String username, String password, boolean isOfficial) {
        try (Connection connection = DriverManager.getConnection(url, dbUsername, dbPassword)) {
            String query;
            if (isOfficial) {
                query = "SELECT * FROM officials WHERE name = ? AND password = ?";
            } else {
                query = "SELECT * FROM users WHERE username = ? AND password = ?";
            }
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();

            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private static boolean isOfficial(String username) {
        try (Connection connection = DriverManager.getConnection(url, dbUsername, dbPassword)) {
            String query = "SELECT * FROM officials WHERE name = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();

            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    static void display() {
        Stage primaryStage = new Stage();
        display(primaryStage);
    }
}
