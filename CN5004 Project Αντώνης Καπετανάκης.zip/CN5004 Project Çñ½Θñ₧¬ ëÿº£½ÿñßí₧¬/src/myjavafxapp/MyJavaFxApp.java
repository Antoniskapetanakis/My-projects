    
package myjavafxapp;

import javafx.application.Application;
import javafx.stage.Stage;

public class MyJavaFxApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
Login.display(primaryStage);
    }
    
    public static void main(String[] args) {
      launch(args);
    }
    
}
