
package myjavafxapp;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ReportBook {
    public static void display() {
        
        Stage reportStage = new Stage();
        reportStage.setTitle("Report Book Issue");
   
        Label titleLabel = new Label("Report Book Issue");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        Label bookLabel = new Label("Book Title:");
        TextArea bookTextArea = new TextArea();
        bookTextArea.setPromptText("Enter the title of the book");

        Label issueLabel = new Label("Issue Description:");
        TextArea issueTextArea = new TextArea();
        issueTextArea.setPromptText("Describe the issue with the book");

        // Submit button
        Button submitButton = new Button("Submit");
        submitButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 16px;");
        submitButton.setOnAction(event -> {
            // Logic to handle report submission can be added here
            System.out.println("Issue reported!");
            reportStage.close();
        });

        // Creating the layout for the report form
        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(20));
        vbox.setAlignment(Pos.CENTER);

        GridPane gridPane = new GridPane();
        gridPane.setVgap(10);
        gridPane.setHgap(10);
        gridPane.setAlignment(Pos.CENTER);

        gridPane.add(titleLabel, 0, 0, 2, 1);
        gridPane.add(bookLabel, 0, 1);
        gridPane.add(bookTextArea, 1, 1);
        gridPane.add(issueLabel, 0, 2);
        gridPane.add(issueTextArea, 1, 2);

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.getChildren().add(submitButton);

        vbox.getChildren().addAll(gridPane, buttonBox);
 Button homeButton = new Button("Home");
        homeButton.setOnAction(event -> MainWindow.display());

        vbox.getChildren().add(homeButton);
        Scene scene = new Scene(vbox, 400, 250);

        reportStage.setScene(scene);
        reportStage.show();
    }
}
