package myjavafxapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class MainWindow { 
    private static final String url = "jdbc:mysql://localhost:3306/library_database";
    private static final String username = "root";
    private static final String password = "";
    
    public static void display(Stage primaryStage, String username, boolean isOfficial) {
        try {
            // Attempt to establish the database connection
            Connection connection = DriverManager.getConnection(url, username, password);
            System.out.println("Connected to the database!");
        } catch (SQLException e) {
            // Log an error message if connection fails
            System.out.println("Failed to connect to the database: " + e.getMessage());
        }
         if (isOfficial) {
        // Redirect to the official's main window
        of_mainwindow.display(primaryStage, username);
        return; // Exit the method to prevent the user's main window from being displayed
    }
        // Welcome message for the borrower
        Label welcomeLabel = new Label("Welcome, " + username + "!");
        welcomeLabel.setStyle("-fx-font-size: 20px;");

        // Title label for services
        Label titleLabel = new Label("Services");
        titleLabel.setStyle("-fx-font-size: 24px;");

        // Search bar for books
        TextField searchField = new TextField();
        searchField.setPromptText("Search Books");
        searchField.setPrefWidth(200);

        // Creating the layout for services
        GridPane servicesPane = new GridPane();
        servicesPane.setPadding(new Insets(20));
        servicesPane.setHgap(10);
        servicesPane.setVgap(10);
        servicesPane.setAlignment(Pos.CENTER);
        servicesPane.add(welcomeLabel, 0, 0, 2, 1);
        servicesPane.add(titleLabel, 0, 1, 2, 1);
        servicesPane.add(searchField, 0, 2, 2, 1);

        // Creating buttons for services
        Button addButton = new Button("Loan Book");
        Button issueButton = new Button("Report Book");
        Button returnButton = new Button("Return Book");
        addButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 16px;");
        issueButton.setStyle("-fx-background-color: #FF5722; -fx-text-fill: white; -fx-font-size: 16px;");
        returnButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white; -fx-font-size: 16px;");
        addButton.setPrefWidth(120);
        issueButton.setPrefWidth(120);
        returnButton.setPrefWidth(120);

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.getChildren().addAll(addButton, issueButton, returnButton);
        servicesPane.add(buttonBox, 0, 3, 2, 1);

        // Create VBox to hold book cards within a ScrollPane
        VBox bookCards = new VBox(20); 
        bookCards.setAlignment(Pos.CENTER); 
        ScrollPane bookScrollPane = new ScrollPane(bookCards);
        bookScrollPane.setFitToWidth(true);
        bookScrollPane.setPrefViewportWidth(300);

        // Create and add book cards
        VBox bookCard1 = createIndividualBookCard("Pride and Prejudice", "Jane Austen", "1813", "Romance/Comedy", "file:///C:/Users/ΛΙΤΣΑ/OneDrive/Documents/Studies%20Repository/Computer%20Science,%20Year%202%20Eξάμηνο%20Β/Advanced%20Programming/MyJavaFxApp/Images/Pride%20and%20Prejudice.jpg");
        VBox bookCard2 = createIndividualBookCard("The Sunrise", "Victoria Hislop", "2014", "Drama", "file:///C:/Users/ΛΙΤΣΑ/OneDrive/Documents/Studies%20Repository/Computer%20Science,%20Year%202%20Eξάμηνο%20Β/Advanced%20Programming/MyJavaFxApp/Images/The%20Sunrise.jpg");
        VBox bookCard3 = createIndividualBookCard("Misery", "Stephen King", "1987", "Thriller", "file:///C:/Users/ΛΙΤΣΑ/OneDrive/Documents/Studies%20Repository/Computer%20Science,%20Year%202%20Eξάμηνο%20Β/Advanced%20Programming/MyJavaFxApp/Images/Misery.jpg");
        VBox bookCard4 = createIndividualBookCard("Inferno", "Dan Brown", "2013", "Mystery", "file:///C:/Users/ΛΙΤΣΑ/OneDrive/Documents/Studies%20Repository/Computer%20Science,%20Year%202%20Eξάμηνο%20Β/Advanced%20Programming/MyJavaFxApp/Images/Inferno.jpg");
        VBox bookCard5 = createIndividualBookCard("Les Miserables", "Victor Hugo", "1862", "Social", "file:///C:/Users/ΛΙΤΣΑ/OneDrive/Documents/Studies%20Repository/Computer%20Science,%20Year%202%20Eξάμηνο%20Β/Advanced%20Programming/MyJavaFxApp/Images/Les%20Miserables.jpg");
        bookCards.getChildren().addAll(bookCard1, bookCard2, bookCard3, bookCard4, bookCard5);

        VBox borrowerCards = new VBox(20);
        borrowerCards.setAlignment(Pos.CENTER_LEFT); 
        ScrollPane borrowerScrollPane = new ScrollPane(borrowerCards);
        borrowerScrollPane.setFitToWidth(true);
        borrowerScrollPane.setPrefViewportWidth(300);

        // Create and add borrower cards
        VBox borrowerCard1 = createBorrowerCard("George", "1", "Pride and Prejudice", "george@mail.com", "file:///C:/Users/ΛΙΤΣΑ/OneDrive/Documents/Studies%20Repository/Computer%20Science,%20Year%202%20Eξάμηνο%20Β/Advanced%20Programming/MyJavaFxApp/Images/borrower%20photo.png");
        VBox borrowerCard2 = createBorrowerCard("John", "2", "The Sunrise", "John@mail.com", "file:///C:/Users/ΛΙΤΣΑ/OneDrive/Documents/Studies%20Repository/Computer%20Science,%20Year%202%20Eξάμηνο%20Β/Advanced%20Programming/MyJavaFxApp/Images/borrower%20photo.png");
        VBox borrowerCard3 = createBorrowerCard("Maria", "3", "Misery", "Maria@mail.com", "file:///C:/Users/ΛΙΤΣΑ/OneDrive/Documents/Studies%20Repository/Computer%20Science,%20Year%202%20Eξάμηνο%20Β/Advanced%20Programming/MyJavaFxApp/Images/borrower%20photo.png");
        VBox borrowerCard4 = createBorrowerCard("Jim", "4", "Inferno", "Jim@mail.com", "file:///C:/Users/ΛΙΤΣΑ/OneDrive/Documents/Studies%20Repository/Computer%20Science,%20Year%202%20Eξάμηνο%20Β/Advanced%20Programming/MyJavaFxApp/Images/borrower%20photo.png");
        VBox borrowerCard5 = createBorrowerCard("Vanessa", "5", "Les Miserables", "Vanessa@mail.com", "file:///C:/Users/ΛΙΤΣΑ/OneDrive/Documents/Studies%20Repository/Computer%20Science,%20Year%202%20Eξάμηνο%20Β/Advanced%20Programming/MyJavaFxApp/Images/borrower%20photo.png");
        borrowerCards.getChildren().addAll(borrowerCard1, borrowerCard2, borrowerCard3, borrowerCard4, borrowerCard5);

        // Create a menu bar
        MenuBar menuBar = new MenuBar();
        Menu homeMenu = new Menu("Home");
        Menu contactMenu = new Menu("Contact");
        Menu aboutMenu = new Menu("About");
         Menu logoutMenu = new Menu("Logout");
        MenuItem logoutMenuItem = new MenuItem("Logout");
        logoutMenuItem.setOnAction(event -> {
            primaryStage.close(); 
            Login.display(); 
        });
        logoutMenu.getItems().add(logoutMenuItem);
        MenuItem homeMenuItem = new MenuItem("Home");

        MenuItem aboutMenuItem = new MenuItem("About");
        aboutMenuItem.setOnAction(event -> About.display());
        aboutMenu.getItems().add(aboutMenuItem);
        MenuItem contactMenuItem = new MenuItem("Contact");
        contactMenuItem.setOnAction(event -> Contact.display());
        contactMenu.getItems().add(contactMenuItem);
       
        // Add menus to the menu bar
        menuBar.getMenus().addAll(homeMenu, contactMenu, aboutMenu, logoutMenu);

        // Cookie policy notification
        Label cookieNotification = new Label("By using this site, you agree to our use of cookies.");
        cookieNotification.setStyle("-fx-font-size: 12px; -fx-text-fill: gray;");

        // VBox to hold copyright label and cookie policy notification
        VBox bottomPane = new VBox(5);
        bottomPane.setAlignment(Pos.CENTER);
        bottomPane.getChildren().addAll(createCopyrightLabel(), cookieNotification);

 
        BorderPane borderPane = new BorderPane();
        borderPane.setTop(menuBar);
        borderPane.setLeft(servicesPane);
        borderPane.setCenter(bookScrollPane); 
        borderPane.setRight(borrowerScrollPane); 
        borderPane.setBottom(bottomPane); 
        borderPane.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, null, null)));

        // Creating the scene
        Scene scene = new Scene(borderPane, 1000, 600); 

        primaryStage.setTitle("Library Management System");
        primaryStage.setScene(scene);
        primaryStage.show();

        // Event handler for the "Report Book" button
        issueButton.setOnAction(event -> ReportBook.display());

        addButton.setOnAction(event -> LoanBook.display());

        // Event handler for the "Return Book" button
        returnButton.setOnAction(event -> ReturnBook.display());
    }


    private static VBox createIndividualBookCard(String title, String author, String releaseDate, String plot, String imagePath) {
        // Create labels for book information
        Label titleLabel = new Label("Title: " + title);
        Label authorLabel = new Label("Author: " + author);
        Label releaseDateLabel = new Label("Release Date: " + releaseDate);
        Label plotLabel = new Label("Plot: " + plot);

        // Create ImageView for the book image
        ImageView imageView = new ImageView(new Image(imagePath));
        imageView.setFitWidth(100); 
        imageView.setPreserveRatio(true); 

        VBox card = new VBox(10); 
        card.setPadding(new Insets(10)); 
        card.getChildren().addAll(imageView, titleLabel, authorLabel, releaseDateLabel, plotLabel);

        return card;
    }

    // Helper method to create a borrower card
    private static VBox createBorrowerCard(String username, String ID, String bookBorrowed, String email, String imagePath) {
    
        Label usernameLabel = new Label("Username: " + username);
        Label IDLabel = new Label("ID: " + ID);
        Label bookBorrowedLabel = new Label("Book Borrowed: " + bookBorrowed);
        Label emailLabel = new Label("Email: " + email);

        // Create ImageView for the borrower image
        ImageView imageView = new ImageView(new Image(imagePath));
        imageView.setFitWidth(100); 
        imageView.setPreserveRatio(true); 

        // Create VBox to hold labels and image
        VBox card = new VBox(10); 
        card.setPadding(new Insets(10));
        card.getChildren().addAll(imageView, usernameLabel, IDLabel, bookBorrowedLabel, emailLabel);

        return card;
    }

    private static Label createCopyrightLabel() {
        Label copyrightLabel = new Label("\u00A9 2024 MyLibrary");
        copyrightLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: gray;");
        copyrightLabel.setAlignment(Pos.CENTER);
        return copyrightLabel;
    }

    static void display() {
    Stage primaryStage = new Stage();
    MainWindow.display(primaryStage, "", false);
}

}


