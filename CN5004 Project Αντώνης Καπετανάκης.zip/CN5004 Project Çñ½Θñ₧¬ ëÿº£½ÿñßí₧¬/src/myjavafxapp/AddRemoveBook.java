package myjavafxapp;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage; 
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class AddRemoveBook extends Application {

    private static final String url = "jdbc:mysql://localhost:3306/library_database";
    private static final String username = "root";
    private static final String password = "";

    private ListView<Book> listView;

    public static void main(String[] args) {
        launch(args);
    }
    private boolean isOfficial;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Add/Remove Book");

        List<Book> bookList = fetchBooks();
        ObservableList<Book> books = FXCollections.observableArrayList(bookList);

        listView = new ListView<>(books);
        listView.setCellFactory(param -> new BookListViewCell());

        Button addButton = new Button("Add Book");
        Button removeButton = new Button("Remove Book");
      Button homeButton = new Button("Home");
    homeButton.setOnAction(event -> {
        if (isOfficial) {
            Contact.display(primaryStage, username);
        } else {
            of_mainwindow.display(primaryStage, username);
        }
    });
        addButton.setOnAction(event -> addBookDialog());

        removeButton.setOnAction(event -> {
            Book selectedBook = listView.getSelectionModel().getSelectedItem();
            if (selectedBook != null) {
                removeBook(selectedBook);
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.setHeaderText(null);
                alert.setContentText("Please select a book to remove.");
                alert.showAndWait();
            }
        });
 addButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-weight: bold;");
        removeButton.setStyle("-fx-background-color: #f44336; -fx-text-fill: white; -fx-font-weight: bold;");
        homeButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white; -fx-font-weight: bold;");

        // Apply styles to list view
        listView.setStyle("-fx-border-color: #ccc; -fx-border-width: 2px;");
        VBox buttonsBox = new VBox(10, addButton, removeButton);
        buttonsBox.setAlignment(Pos.CENTER);

        VBox root = new VBox(10);
        root.setPadding(new Insets(10));
        root.setAlignment(Pos.CENTER);
        root.getChildren().addAll(new Label("Book List"), listView, buttonsBox, homeButton);

        Scene scene = new Scene(root, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void addBookDialog() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Add New Book");
        dialog.setHeaderText("Enter book details:");
        dialog.setContentText("Title:");
        Optional<String> titleResult = dialog.showAndWait();
        titleResult.ifPresent(title -> {
            TextInputDialog authorDialog = new TextInputDialog();
            authorDialog.setTitle("Add New Book");
            authorDialog.setHeaderText("Enter book details:");
            authorDialog.setContentText("Author:");
            Optional<String> authorResult = authorDialog.showAndWait();
            authorResult.ifPresent(author -> {
                TextInputDialog releaseDateDialog = new TextInputDialog();
                releaseDateDialog.setTitle("Add New Book");
                releaseDateDialog.setHeaderText("Enter book details:");
                releaseDateDialog.setContentText("Release Date (YYYY-MM-DD):");
                Optional<String> releaseDateResult = releaseDateDialog.showAndWait();
                releaseDateResult.ifPresent(releaseDateStr -> {
                    try {
                        LocalDate releaseDate = LocalDate.parse(releaseDateStr);
                        TextInputDialog genreDialog = new TextInputDialog();
                        genreDialog.setTitle("Add New Book");
                        genreDialog.setHeaderText("Enter book details:");
                        genreDialog.setContentText("Genre:");
                        Optional<String> genreResult = genreDialog.showAndWait();
                        genreResult.ifPresent(genre -> {
                            TextInputDialog imageUrlDialog = new TextInputDialog();
                            imageUrlDialog.setTitle("Add New Book");
                            imageUrlDialog.setHeaderText("Enter book details:");
                            imageUrlDialog.setContentText("Image URL:");
                            Optional<String> imageUrlResult = imageUrlDialog.showAndWait();
                            imageUrlResult.ifPresent(imageUrl -> {
                                addBook(title, author, releaseDate, genre, imageUrl);
                            });
                        });
                    } catch (Exception e) {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error");
                        alert.setHeaderText("Invalid Input");
                        alert.setContentText("Please enter valid data.");
                        alert.showAndWait();
                    }
                });
            });
        });
    }

    private List<Book> fetchBooks() {
        List<Book> bookList = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String query = "SELECT book_id, title, author, release_date, genre, image_url FROM books";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                int id = resultSet.getInt("book_id");
                String title = resultSet.getString("title");
                String author = resultSet.getString("author");
                Date releaseDate = resultSet.getDate("release_date");
                String genre = resultSet.getString("genre");
                String imagePath = resultSet.getString("image_url");
                Book book = new Book(id, title, author, releaseDate, genre, imagePath);
                bookList.add(book);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return bookList;
    }

    public class Book {
        private int book_id;
        private String title;
        private String author;
        private Date release_date;
        private String genre;
        private String image_url;

        public Book(int id, String title, String author, Date release_date, String genre, String imagePath) {
            this.book_id = id;
            this.title = title;
            this.author = author;
            this.release_date = release_date;
            this.genre = genre;
            this.image_url = imagePath;
        }

        public int getId() {
            return book_id;
        }

        public String getTitle() {
            return title;
        }

        public String getAuthor() {
            return author;
        }

        public Date getReleaseDate() {
            return release_date;
        }

        public String getGenre() {
            return genre;
        }

        public String getImageUrl() {
            return image_url;
        }

        public String toFormattedString() {
            return "Title: " + title + "\nAuthor: " + author + "\nYear: " + release_date + "\nGenre: " + genre;
        }
    }

    private class BookListViewCell extends ListCell<Book> {
        @Override
        public void updateItem(Book book, boolean empty) {
            super.updateItem(book, empty);
            if (empty || book == null) {
                setText(null);
                setGraphic(null);
            } else {
                HBox hbox = new HBox(10);
                Label label = new Label(book.toFormattedString());
                ImageView imageView = new ImageView(new Image(book.getImageUrl()));
                imageView.setFitWidth(50);
                imageView.setPreserveRatio(true);
                Button removeButton = new Button("Remove");
                hbox.getChildren().addAll(label, imageView, removeButton);
                setGraphic(hbox);

                removeButton.setOnAction(event -> removeBook(book));
            }
        }
    }

    private void removeBook(Book book) {
        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String query = "DELETE FROM books WHERE book_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, book.getId());
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Book removed: " + book.getTitle());
                refreshListView();
            } else {
                System.out.println("Failed to remove book: " + book.getTitle());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void refreshListView() {
        Stage stage = (Stage) listView.getScene().getWindow();
        start(stage);
    }

    private void addBook(String title, String author, LocalDate releaseDate, String genre, String imageUrl) {
        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String sql = "INSERT INTO books (title, author, release_date, genre, image_url) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, title);
            statement.setString(2, author);
            statement.setDate(3, Date.valueOf(releaseDate));
            statement.setString(4, genre);
            statement.setString(5, imageUrl);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Book added successfully.");
                refreshListView();
            } else {
                System.out.println("Failed to add book.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
