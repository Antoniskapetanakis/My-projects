
package myjavafxapp;


import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ReturnBook {
    public static void display() {

        Stage returnBookStage = new Stage();
        returnBookStage.setTitle("Return Book");

        // Text field for entering the book title to return
        TextField bookTitleField = new TextField();
        bookTitleField.setPromptText("Enter Book Title to Return");
        bookTitleField.setMaxWidth(250);
        bookTitleField.setStyle("-fx-font-size: 14px;");

        // Text field for entering the username
        TextField usernameField = new TextField();
        usernameField.setPromptText("Enter Your Username");
        usernameField.setMaxWidth(250);
        usernameField.setStyle("-fx-font-size: 14px;");

        // Add button to confirm book return
        Button returnButton = new Button("Return Book");
        returnButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        returnButton.setOnAction(event -> {
            String bookTitle = bookTitleField.getText();
            String username = usernameField.getText();
            if (!bookTitle.isEmpty() && !username.isEmpty()) {
                returnBook(bookTitle, username);
                System.out.println("Book returned: " + bookTitle);
                returnBookStage.close();
            } else {
                showErrorAlert("Please enter both the book title and your username.");
            }
        });

        // Create labels
        Label titleLabel = new Label("Return Book");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        titleLabel.setTextFill(Color.web("#0076a3"));

        Label selectLabel = new Label("Select a book to return:");
        selectLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 14));

        // Create layout
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);
        layout.getChildren().addAll(titleLabel, selectLabel, bookTitleField, usernameField, returnButton);

        // Home button
        Button homeButton = new Button("Home");
        homeButton.setOnAction(event -> MainWindow.display());
        homeButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white; -fx-font-size: 14px;");

        // Create BorderPane for overall layout
        BorderPane borderPane = new BorderPane();
        borderPane.setCenter(layout);
        borderPane.setBottom(homeButton);
        BorderPane.setAlignment(homeButton, Pos.CENTER);

        Scene scene = new Scene(borderPane, 400, 300);
        returnBookStage.setScene(scene);
        returnBookStage.show();
    }

    // Method to handle returning a book
    private static void returnBook(String bookTitle, String username) {
        try (Connection connection = DatabaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "DELETE FROM borrowedbooks WHERE book_title = ? AND username = ?")) {
            statement.setString(1, bookTitle);
            statement.setString(2, username);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void showErrorAlert(String message) {
        Stage alertStage = new Stage();
        alertStage.setTitle("Error");

        Label label = new Label(message);
        Button closeButton = new Button("OK");
        closeButton.setOnAction(event -> alertStage.close());

        VBox layout = new VBox(10);
        layout.getChildren().addAll(label, closeButton);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));

        Scene scene = new Scene(layout, 300, 100);
        alertStage.setScene(scene);
        alertStage.show();
    }

    private static void close() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
