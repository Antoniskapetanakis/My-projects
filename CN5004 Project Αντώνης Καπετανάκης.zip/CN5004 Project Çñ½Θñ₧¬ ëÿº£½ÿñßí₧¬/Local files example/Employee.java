
package Rent_A_Car;

public class Employee {
    String Id;
    String name;
    String surname;
    String taxNumber;
    double salary;
}
