
<! ––The whole w3css,html,javascript and php code for index.php––> 
  <!--Basic Set -->
<!DOCTYPE html>
<html lang="en">
<head>
<center>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"">
<script src="script.js" defer></script>
<div id="google_translate_element"></div>
<script type="text/javascript">
function googleTranslateElementInit() {
 new google.translate.TranslateElement({
pageLanguage: 'en', layout: 
google.translate.TranslateElement.InlineLayout.HORIZONTAL, autoDisplay: 
false, includedLanguages: 'fr,de,es,', gaTrack: true, gaId: 'YOUR_API_KEY'
}, 'google_translate_element');
}
</script>
<script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</body>
</html>
<body style="background-color: #d1f2eb ;">
	
<nav>
<ul>
<li><a href="index.php">Home</a></li>
<li><a href="about.html">About</a></li>
<li><a href="contact.php">Contact</a></li>
<li><a href="upcoming.html">Upcoming</a></li>
<li><a href="Privacy Policy.html">Privacy Policy</a></li>

</ul>
</nav>
	
<header>
<img id="logo" src="movie logo.jpg" alt="">
</header>
 <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 40px;
        }

        button.popupBtn {
            background-color: #FFFFFF;
            color: #000;
            padding: 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            position: absolute;
            top: 88px;
            right: 100px;
        }

        button.popupBtn2 {
            background-color: #FFFFFF;
            color: #000;
            padding: 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            position: absolute;
            top: 130px;
            right: 100px;
        }

        .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            z-index: 1;
        }

        .close {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 20px;
            cursor: pointer;
        }

        .popup.show {
            display: block;
        }

        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        form {
            width: 100%;
            max-width: 300px;
            margin-bottom: 20px;
            padding: 15px;
        }

        h2 {
            margin-bottom: 10px;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input,
        select {
            width: 100%;
            padding: 8px;
            margin-bottom: 12px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            background-color: #000;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #333;
        }
    </style>
</head>
<body>
  <!-- Buttons to Trigger Register and Login Popups -->

<button class="popupBtn" id="registerPopupBtn">Register</button>
<button class="popupBtn2" id="loginPopupBtn">Login</button>

<div class="popup" id="registerPopupContainer">
    <span class="close" id="registerCloseBtn" onclick="togglePopup('registerPopupContainer')">&times;</span>
    <div class="container">
        <form id="registerForm" action="register.php" method="POST">
            <h2>Register</h2>
            <label for="registerName">Name:</label>
            <input type="text" id="registerName" name="username" required>

            <label for="registerEmail">Email:</label>
            <input type="email" id="registerEmail" name="email" required>

            <label for="registerPassword">Password:</label>
            <input type="password" id="registerPassword" name="password" required>

            <label for="registerUserType">User Type:</label>
            <select name="userType" id="registerUserType">
                <option value="user">User</option>
                <option value="employee">Employee</option>
                <option value="admin">Admin</option>
            </select>

            <button type="submit">Register</button>
        </form>
    </div>
</div>

<div class="popup" id="loginPopupContainer">
    <span class="close" id="loginCloseBtn" onclick="togglePopup('loginPopupContainer')">&times;</span>
    <div class="container">
        <form id="loginForm" action="login.php" method="POST">
            <h2>Login</h2>
            <label for="loginEmail">Email:</label>
            <input type="email" id="loginEmail" name="email" required>

            <label for="loginPassword">Password:</label>
            <input type="password" id="loginPassword" name="password" required>

            <label for="loginUserType">User Type:</label>
            <select name="userType" id="loginUserType">
                <option value="user">User</option>
                <option value="employee">Employee</option>
                <option value="admin">Admin</option>
            </select>

            <button type="submit">Login</button>
        </form>
    </div>
</div>
  <!-- JavaScript to handle popup toggling -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        function togglePopup(popupId) {
            const popupContainer = document.getElementById(popupId);
            popupContainer.classList.toggle('show');
        }

        const loginPopupBtn = document.getElementById('loginPopupBtn');
        const loginCloseBtn = document.getElementById('loginCloseBtn');

        loginPopupBtn.addEventListener('click', function () {
            togglePopup('loginPopupContainer');
        });

        loginCloseBtn.addEventListener('click', function () {
            togglePopup('loginPopupContainer');
        });

        const registerPopupBtn = document.getElementById('registerPopupBtn');
        const registerCloseBtn = document.getElementById('registerCloseBtn');

        registerPopupBtn.addEventListener('click', function () {
            togglePopup('registerPopupContainer');
        });

        registerCloseBtn.addEventListener('click', function () {
            togglePopup('registerPopupContainer');
        });
    });
</script>
 <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f2f2f2;
        }

        .carousel-container {
            position: relative;
            width: 400px;
            overflow: hidden;
        }

        .carousel {
            display: flex;
            transition: transform 0.5s ease-in-out;
        }

        .carousel-item {
            min-width: 100%;
            box-sizing: border-box;
            text-align: center;
        }

        .carousel-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }

        .carousel img {
            width: 100%;
            height: auto;
            border-radius: 8px;
            margin-bottom: 10px;
        }

        .arrow {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            font-size: 24px;
            cursor: pointer;
            color: #333;
            background-color: #fff;
            padding: 8px;
            border-radius: 50%;
            border: 1px solid #ccc;
            user-select: none;
        }

        .arrow-prev {
            left: 10px;
        }

        .arrow-next {
            right: 10px;
        }
    </style>
</head>
<body>
  <!-- Carousel -->
<div class="carousel-container">
    <div class="carousel">
        <div class="carousel-item">
            <div class="carousel-content">
                <img src="https://i.ebayimg.com/images/g/ItgAAOSwfWhhZOzF/s-l1600.jpg" alt="Image 1">
                <p>The crew of the spaceship Nostromo is awakened from hypersleep to investigate a distress signal from a distant moon. </p>
            </div>
        </div>
        <div class="carousel-item">
            <div class="carousel-content">
                <img src="https://m.media-amazon.com/images/M/MV5BMjExMjkwNTQ0Nl5BMl5BanBnXkFtZTcwNTY0OTk1Mw@@._V1_.jpg" alt="Image 2">
                <p>com Cobb, a skilled thief, is a specialist in the dangerous art of extraction—stealing valuable secrets from deep within the subconscious while people dream..</p>
            </div>
        </div>
        <div class="carousel-item">
            <div class="carousel-content">
                <img src="https://m.media-amazon.com/images/M/MV5BNzA5ZDNlZWMtM2NhNS00NDJjLTk4NDItYTRmY2EwMWZlMTY3XkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_.jpg" alt="Image 3">
                <p>In the epic conclusion to the trilogy, Frodo and Sam continue their perilous journey to Mount Doom, while Aragorn leads the forces of good against the dark lord Sauron. .</p>
            </div>
        </div>
        <div class="carousel-item">
            <div class="carousel-content">
                <img src="https://m.media-amazon.com/images/M/MV5BOGFjYWNkMTMtMTg1ZC00Y2I4LTg0ZTYtN2ZlMzI4MGQwNzg4XkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_.jpg" alt="Image 4">
                <p>Godzilla faces off against ancient super-species, including the three-headed King Ghidorah, as humanity grapples with its survival. .</p>
            </div>
        </div>
        <div class="carousel-item">
            <div class="carousel-content">
                <img src="https://www.movieposters.com/cdn/shop/products/108b520c55e3c9760f77a06110d6a73b_480x.progressive.jpg?v=1573652543" alt="Image 5">
                <p>After the devastating events of "Avengers: Infinity War," the remaining heroes must find a way to undo the chaos caused by the mad titan, Thanos.</p>
            </div>
        </div>
    </div>
    <div class="arrow arrow-prev" onclick="prevSlide()">&#8249;</div>
    <div class="arrow arrow-next" onclick="nextSlide()">&#8250;</div>
</div>

<script>
    let currentIndex = 0;

    function showSlide(index) {
        const carousel = document.querySelector('.carousel');
        const totalSlides = document.querySelectorAll('.carousel-item').length;

        if (index < 0) {
            currentIndex = totalSlides - 1;
        } else if (index >= totalSlides) {
            currentIndex = 0;
        } else {
            currentIndex = index;
        }

        const translateValue = -currentIndex * 100 + '%';
        carousel.style.transform = 'translateX(' + translateValue + ')';
    }

    function prevSlide() {
        showSlide(currentIndex - 1);
    }

    function nextSlide() {
        showSlide(currentIndex + 1);
    }
</script>
</body>
</body>
</html>
<style>
body {
margin: 0;
font-family: Arial, sans-serif;
}
header {
background-color: #333;
padding: 10px;
text-align: center;
color: white;
}

nav {
background-color: #f4f4f4;
}
ul {
list-style-type: none;
margin: 0;
padding: 0;
overflow: hidden;
}

li {
float: left;
}

a {
display: block;
color: #333;
text-align: center;
padding: 14px 16px;
text-decoration: none;
}
a:hover {
background-color: #ddd;
}
</style>
<style>
body {
margin: 0;
padding: 0;
font-family: Arial, sans-serif;
}
header {
background-color: #333;
padding: 10px;
text-align: center;
}
#logo {
max-width: 150px; 
height: auto;
display: block;
margin: 0 auto;
}
</style>
</head>
<body>
    
</body>
</head>
<title>Movie Booking System</title>
<style>
body {
font-family: Arial, sans-serif;
margin: 0;
padding: 0;
background-color: #f4f4f4;
}
header {
background-color: #333;
color: white;
text-align: center;
padding: 10px;
        }

.movie-container {
display: flex;
flex-wrap: wrap;
justify-content: space-around;
padding: 10px;
}

.movie-card {
width: 45%;
margin: 10px;
box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
overflow: hidden;
transition: transform 0.3s;
cursor: pointer;
background-color: white;
}

.movie-card:hover {
transform: scale(1.05);
}

.movie-card img {
width: 50%;
height: auto;
}

.movie-card-info {
padding: 10px;
text-align: center;
}

.modal {
display: none;
position: fixed;
z-index: 1;
left: 0;
top: 0;
width: 100%;
height: 100%;
overflow: auto;
background-color: rgb(0, 0, 0);
background-color: rgba(0, 0, 0, 0.4);
padding-top: 60px;
}
.modal-content {
background-color: #fefefe;
margin: 5% auto;
padding: 20px;
border: 1px solid #888;
width: 80%;
}
.close {
color: #aaa;
float: right;
font-size: 28px;
font-weight: bold;
}
.close:hover,
.close:focus {
color: black;
text-decoration: none;
cursor: pointer;
}
@media screen and (max-width: 768px) {
.movie-card {
width: 100%;
}
}
</style>
</head>
<body>
<header>
<h1>Movie Corner!</h1>
</header>


</body>
</html>
</body>
</html>
</body>
</html>
<style>
body {
font-family: Arial, sans-serif;
display: flex;
align-items: center;
justify-content: center;
flex-wrap: wrap;
padding: 20px;
}

.movie-card {
margin: 20px;
padding: 20px;
border: 1px solid #ccc;
text-align: center;
}
.movie-card img {
max-width: 100%;
height: auto;
margin-bottom: 10px;
}
.movie-card-info {
margin-bottom: 20px;
}
.modal {
display: none;
position: fixed;
top: 50%;
left: 50%;
transform: translate(-50%, -50%);
padding: 20px;
background-color: #fff;
border: 1px solid #000;
z-index: 1000;
text-align: center;
}
.modal-content {
margin-top: 20px;
}
.close {
position: absolute;
top: 10px;
right: 10px;
cursor: pointer;
}
button {
padding: 10px;
margin-right: 10px;
background-color: #4caf50;
color: white;
border: none;
border-radius: 5px;
cursor: pointer;
}
button:hover {
background-color: #45a049;
}
.back-button {
margin-top: 20px;
padding: 10px;
background-color: #333;
color: white;
border: none;
border-radius: 5px;
cursor: pointer;
}
.back-button:hover {
background-color: #555;
}
</style>
</head>
<body>
<h2>Movies: Playing Now</h2>
  <!-- Movie Cards -->
<?php
require "makeDBConnection.php";

$sql = "SELECT * FROM movies LIMIT 5";	  
$result = $conn->query($sql);
if ($result->num_rows > 0) {
while ($row = $result->fetch_assoc()) {
echo "<div class='movie-card'>";
echo "<img src='" . $row['poster_url'] . "' alt='" . $row['title'] . "'>";
echo "<div class='movie-card-info'>";
echo "<h3>" . $row['title'] . "</h3>";
echo "<p>" . $row['genre'] . "</p>";
echo "<p>" . $row['duration_minutes'] . " mins</p>";
echo "<button onclick='openMovieModal(" . $row['id'] . ")'>View Details</button>";
echo "<button onclick='openBookingModal(" . $row['id'] . ")'>Book Now</button>";
echo "</div></div>";
}
} else {
echo "No movies found.";
}

$conn->close();
?>
<style>
.modal-content {
    max-width: 400px;
    margin: auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    background-color: #fff;
}

label {
    display: block;
    margin-bottom: 8px;
}

select {
    width: 100%;
    padding: 8px;
    margin-bottom: 16px;
    box-sizing: border-box;
}

button {
    padding: 10px;
    background-color: #4caf50;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-right: 10px;
}

button:hover {
    background-color: #45a049;
}

.back-button {
    background-color: #ccc;
}

.back-button:hover {
    background-color: #999;
}

@media screen and (max-width: 600px) {
    .modal-content {
        max-width: 100%;
        padding: 10px;
    }

    select {
        margin-bottom: 10px;
    }

    button {
        padding: 8px;
    }

    .seat-container {
        gap: 3px;
    }

    .seat {
        width: 20px;
        height: 20px;
    }
}
</style>

</head>
</head>
<body>

<div class="modal" id="movieModal">
<div class="modal-content">
<span class="close" onclick="closeMovieModal()">&times;</span>
<h2 id="modalTitle"></h2>
<div id="modalContent"></div>
<button class="back-button" onclick="goBack()">Back</button>
<button class="book-button" onclick="openBookingModal()">Book Now</button>
</div>
</div>
  <!-- Booking-->
<div class="modal" id="bookingModal">
<div class="modal-content">
<span class="close" onclick="closeBookingModal()">&times;</span>
<h2>Book Now</h2>
<form id="bookingForm">
<label for="day">Select Day:</label>
<select id="day" name="day">
<option value="monday">Monday</option>
<option value="tuesday">Tuesday</option>
<option value="wednesday">Wednesday</option>
<option value="thursday">Thursday</option>
<option value="friday">Friday</option>
<option value="saturday">Saturday</option>
<option value="sunday">Sunday</option>
</select>
<label for="time">Select Time:</label>
<select id="time" name="time">
<option value="17:00">17:00</option>
<option value="18:00">18:00</option>
<option value="19:00">19:00</option>
<option value="20:00">20:00</option>
<option value="21:00">21:00</option>
<option value="22:00">22:00</option>
</select>

<label for="room">Select Room:</label>
<select id="room" name="room">
<option value="mini">Mini (50)</option>
<option value="small">Small (100)</option>
<option value="standard">Standard (200)</option>
<option value="large">Large (300)</option>
<option value="ultra">Ultra (500)</option>
</select>

<label for="seats_booked">Seats Booked:</label>
<input type="text" id="seats_booked" name="seats_booked">


<button type="button" onclick="submitBooking()">Submit Booking</button>
<button class="back-button" onclick="goBack()">Back</button>
</form>
</div>
</div>

<script>
const seatContainer = document.getElementById("seatContainer");
const seatsBookedInput = document.getElementById("seats_booked");
let selectedSeats = [100];

for (let i = 1; i <= 50; i++) {
const seat = document.createElement("div");
seat.className = "seat";
seat.dataset.seatNumber = i;
seat.addEventListener("click", toggleSeat);
seatContainer.appendChild(seat);
}

function toggleSeat(event) {
const clickedSeat = event.target;
const seatNumber = clickedSeat.dataset.seatNumber;

if (selectedSeats.includes(seatNumber)) {
selectedSeats = selectedSeats.filter(seat => seat !== seatNumber);
clickedSeat.classList.remove("booked");
} else {
selectedSeats.push(seatNumber);
clickedSeat.classList.add("booked");
}

updateSeatsBookedInput();
}
function updateSeatsBookedInput() {
seatsBookedInput.value = selectedSeats.join(", ");
}
function openMovieModal(movieId) {
const xhr = new XMLHttpRequest();
xhr.onreadystatechange = function () {
if (xhr.readyState === 4 && xhr.status === 200) {
const movieDetails = JSON.parse(xhr.responseText);
displayMovieDetails(movieDetails);
}
};
xhr.open("GET", "getMovieDetails.php?movieId=" + movieId, true);
xhr.send();
}

function displayMovieDetails(movie) {
const modalTitle = document.getElementById("modalTitle");
const modalContent = document.getElementById("modalContent");
modalTitle.textContent = movie.title;
modalContent.innerHTML = `
<p><strong>Genre:</strong> ${movie.genre}</p>
<p><strong>Duration:</strong> ${movie.duration_minutes} mins</p>
<p><strong>Director:</strong> ${movie.director}</p>
<p><strong>Synopsis:</strong> ${movie.synopsis || "No synopsis available"}</p>
<p><strong>PG:U18</strong></p>
<p><strong>Trailer:</strong> ${movie.trailer_url ? `<a href="${movie.trailer_url}" target="_blank">Watch Trailer</a>` : "No trailer available"}</p>
`;
document.getElementById("movieModal").style.display = "block";
}

function closeMovieModal() {
document.getElementById("movieModal").style.display = "none";
}
function goBack() {
document.getElementById("movieModal").style.display = "none";
}
function openBookingModal() {
document.getElementById("bookingModal").style.display = "block";
}

function closeBookingModal() {
document.getElementById("bookingModal").style.display = "none";
}
function submitBooking() {
const selectedDay = document.getElementById("day").value;
const selectedTime = document.getElementById("time").value;
const selectedRoom = document.getElementById("room").value;
const selectedSeats = document.getElementById("seats_booked").value;
const xhr = new XMLHttpRequest();
xhr.onreadystatechange = function () {
if (xhr.readyState === 4 && xhr.status === 200) {
console.log("Booking submitted successfully!");
closeBookingModal();
displayBookingMessage("Your reservation request is successful!");
}
};

const url = "book movie.php";		
const data = `day=${selectedDay}&time=${selectedTime}&room=${selectedRoom}&seats_booked=${selectedSeats}`;
xhr.open("POST", url, true);
xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xhr.send(data);
}
function displayBookingMessage(message) {
alert(message);
}
</script>
</body>

</html>	
  <style>
    body {
      font-family: Arial, sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      margin: 0;
    }

    .container {
      width: 300px;
      padding: 20px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    form {
      display: flex;
      flex-direction: column;
    }

    label {
      margin-bottom: 8px;
    }

    input {
      padding: 8px;
      margin-bottom: 16px;
    }

    button {
      padding: 10px;
      background-color: #4caf50;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    button:hover {
      background-color: #45a049;
    }

    #message {
      margin-top: 10px;
      color: #4caf50;
    }
  </style>
&copy; All Rights Reserved
</center>
</body>
</html>
</head>
<body>
  <!--Cookies -->
<div id="cookie-consent">
<p>This website uses cookies. By continuing to use this site, you consent to our use of cookies.</p>
<button onclick="acceptCookies()">Accept</button>
<button onclick="declineCookies()">Decline</button>
</div>
<script>
function acceptCookies() {
document.cookie = "cookie_accepted=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/";
document.getElementById('cookie-consent').style.display = 'none';
}
function declineCookies() {   
document.getElementById('cookie-consent').style.display = 'none';
}
</script>
<style>
    #notification-consent {
      position: fixed;
      bottom: 0;
      left: 0;
      width: 100%;
      padding: 10px;
      background: #f0f0f0;
      text-align: center;
    }
  </style>
</head>
<body>

<?php
if (!isset($_COOKIE['notification_accepted'])) {
?>
<div id="notification-consent">
<p>This website may send you notifications. Do you want to allow them?</p>
<button onclick="acceptNotifications()">Allow</button>
<button onclick="blockNotifications()">Block</button>
</div>

<script>
function acceptNotifications() {
document.cookie = "notification_accepted=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/";
alert('You have allowed notifications.');
document.getElementById('notification-consent').style.display = 'none';
}
function blockNotifications() {
alert('You have blocked notifications.');
document.getElementById('notification-consent').style.display = 'none';
}
</script>
<?php
}
?>

</body>
</html>

</body>
</html>

