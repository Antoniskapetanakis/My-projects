<?php
require "makeDBConnection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $operation = $_POST['operation'];

    switch ($operation) {
        case 'insert':
            $title = mysqli_real_escape_string($conn, $_POST['title']);
            $genre = mysqli_real_escape_string($conn, $_POST['genre']);
            $releaseDate = mysqli_real_escape_string($conn, $_POST['release_date']);

            $insertQuery = "INSERT INTO movies (title, genre, release_date) VALUES ('$title', '$genre', '$releaseDate')";

            if ($conn->query($insertQuery) === TRUE) {
                echo "Movie added successfully";
            } else {
                echo "Error adding movie: " . $conn->error;
            }
            break;

        case 'delete':
            $movieId = mysqli_real_escape_string($conn, $_POST['title']);
            $deleteQuery = "DELETE FROM movies WHERE title = 'title'";

            if ($conn->query($deleteQuery) === TRUE) {
                echo "Movie deleted successfully";
            } else {
                echo "Error deleting movie: " . $conn->error;
            }
            break;

        case 'update':
            $title = mysqli_real_escape_string($conn, $_POST['title']);
            $genre = mysqli_real_escape_string($conn, $_POST['genre']);
            $releaseDate = mysqli_real_escape_string($conn, $_POST['release_date']);

            $updateQuery = "UPDATE movies SET title = '$title', genre = '$genre', release_date = '$releaseDate' WHERE title = '$title'";

            if ($conn->query($updateQuery) === TRUE) {
                echo "Movie updated successfully";
            } else {
                echo "Error updating movie: " . $conn->error;
            }
            break;

        default:
            echo "Invalid operation";
            break;
    }
}

$conn->close();
?>
<style>
    body {
        margin: 0;
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
    }
    header {
        background-color: #333;
        padding: 10px;
        text-align: center;
        color: white;
    }
    nav {
        background-color: #f4f4f4;
    }
    ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        overflow: hidden;
    }
    li {
        float: left;
    }
    a {
        display: block;
        color: #333;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
    }
    a:hover {
        background-color: #ddd;
    }
    #logo {
        max-width: 150px;
        height: auto;
        display: block;
        margin: 0 auto;
    }
    h1 {
        text-align: center;
    }
    table {
        width: 80%;
        margin: 20px auto;
        border-collapse: collapse;
        background-color: white;
    }
    th, td {
        border: 1px solid black;
        padding: 10px;
        text-align: left;
    }
    th {
        background-color: #333;
        color: white;
    }
    form {
        display: inline-block;
    }
</style>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <img id="logo" src="movie logo.jpg" alt="">
    </header>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <script src="script.js" defer></script>
    <title>Movie Operations</title>
</head>
<body>
<nav>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about.html">About</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="upcoming.html">Upcoming</a></li>
        <li><a href="Privacy Policy.html">Privacy Policy</a></li>
    </ul>
</nav>

<ul>
    <h3>Employee Settings:</h3>
    <li><a href="index.php">Home</a></li>
    <li><a href="manage system.php">System</a></li>
    <li><a href="approve reservations.php">Reservations</a></li>
    <li><a href="set_schedule.php">Schedule</a></li>
    <li><a href="movie_operations.php">Edit Movie</a></li>
</ul>

<h2>Movie Operations</h2>

<form action="movie_operations.php" method="POST">
    <input type="hidden" name="operation" value="insert">
    <label for="title">Title:</label>
    <input type="text" name="title" required>
    <label for="genre">Genre:</label>
    <input type="text" name="genre" required>
    <label for="release_date">Release Date:</label>
    <input type="date" name="release_date" required>
    <button type="submit">Add Movie</button>
</form>

<hr>

<form action="movie_operations.php" method="POST">
    <input type="hidden" name="operation" value="update">
    <label for="title">Title:</label>
    <input type="text" name="title" required>
    <label for="genre">Genre:</label>
    <input type="text" name="genre" required>
    <label for="release_date">Release Date:</label>
    <input type="date" name="release_date" required>
    <button type="submit">Update Movie</button>
</form>

<hr>
<form action="movie_operations.php" method="POST">
    <input type="hidden" name="operation" value="delete">
    <label for="title">Title:</label>
    <input type="text" name="title" required>
    <button type="submit">Delete Movie</button>
</form>

</body>
</html>
