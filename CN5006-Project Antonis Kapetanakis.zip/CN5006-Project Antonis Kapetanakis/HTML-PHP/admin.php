<?php
require "makeDBConnection.php";

function updateEmployee($conn, $employeeId, $newSalary) {
    $updateSql = "UPDATE users_employees SET salary = $newSalary WHERE user_id = $employeeId";
    $conn->query($updateSql);
}

function deleteEmployee($conn, $employeeId) {
    $deleteSql = "DELETE FROM users_employees WHERE user_id = $employeeId";
    $conn->query($deleteSql);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['update'])) {
        $employeeId = $_POST['employee_id'];
        $newSalary = $_POST['new_salary'];
        updateEmployee($conn, $employeeId, $newSalary);
    } elseif (isset($_POST['delete'])) {
        $employeeId = $_POST['employee_id'];
        deleteEmployee($conn, $employeeId);
    }
}

$sql = "SELECT * FROM users_employees WHERE user_id BETWEEN 6 AND 10";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <script src="script.js" defer></script>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
    </style>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        header {
            background-color: #333;
            padding: 10px;
            text-align: center;
            color: white;
        }

        nav {
            background-color: #f4f4f4;
        }

        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
        }

        li {
            float: left;
        }

        a {
            display: block;
            color: #333;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        a:hover {
            background-color: #ddd;
        }
    </style>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        header {
            background-color: #333;
            padding: 10px;
            text-align: center;
        }

        #logo {
            max-width: 150px;
            height: auto;
            display: block;
            margin: 0 auto;
        }
    </style>
    <title>Admin Page</title>
</head>
<body>
<nav>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about.html">About</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="upcoming.html">Upcoming</a></li>
        <li><a href="Privacy Policy.html">Privacy Policy</a></li>
    </ul>
</nav>
<h3>Employee Settings:</h3>
<li><a href="index.php">Home</a></li>
<li><a href="manage system.php">System</a></li>
<li><a href="approve reservations.php">Reservations</a></li>
<li><a href="set_schedule.php">Schedule</a></li>
<li><a href="movie_operations.php">Edit Movie</a></li>

<h2>Admin Page</h2>

<table>
    <thead>
    <tr>
        <th>User ID</th>
        <th>Username</th>
        <th>Email</th>
        <th>Salary</th>
        <th>Action</th>
    </tr>
    </thead>
    <tbody>
    <?php
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row['user_id']}</td>";
        echo "<td>{$row['username']}</td>";
        echo "<td>{$row['email']}</td>";
        echo "<td>{$row['salary']}</td>";
        echo "<td>
                <form method='post' action=''>
                    <input type='hidden' name='employee_id' value='{$row['user_id']}'>
                    <input type='text' name='new_salary' placeholder='New Salary'>
                    <button type='submit' name='update'>Update</button>
                    <button type='submit' name='delete'>Delete</button>
                </form>
              </td>";
        echo "</tr>";
    }
    ?>
    </tbody>
</table>

</body>
</html>

<?php
$conn->close();
?>
