<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <script src="script.js" defer></script>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        header {
            background-color: #333;
            padding: 20px;
            text-align: center;
            color: white;
        }

        nav {
            background-color: #333;
            overflow: hidden;
        }

        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        li {
            float: left;
            margin: 0;
        }

        a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        a:hover {
            background-color: #ddd;
            color: black;
        }

        img {
            max-width: 100%;
            height: auto;
            display: block;
            margin: 0 auto;
        }

        h1, h3 {
            margin: 0;
        }

        h3.employee-settings {
            text-align: left; 
        }

        .movie-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            padding: 10px;
        }

        .movie-card {
            width: 100%;
            margin: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: transform 0.3s;
            cursor: pointer;
            background-color: white;
        }

        .movie-card:hover {
            transform: scale(1.05);
        }

        .movie-card img {
            width: 100%;
            height: auto;
        }

        .movie-card-info {
            padding: 10px;
            text-align: center;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0, 0, 0);
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 60px;
        }

        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        @media screen and (max-width: 600px) {
            .movie-card {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<header>
    <h1>Employee Dashboard</h1>
    <h3 class="employee-settings">Here is a simple interface for employees to see the details of the system.</h3>
</header>

<nav>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about.html">About</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="Privacy Policy.html">Privacy Policy</a></li>
    </ul>

    <ul>
        <h3 class="employee-settings">Employee Settings:</h3>
        <li><a href="index.php">Home</a></li>
        <li><a href="manage system.php">System</a></li>
        <li><a href="approve reservations.php">Reservations</a></li>
        <li><a href="set_schedule.php">Schedule</a></li>
        <li><a href="movie_operations.php">Edit Movie</a></li>
    </ul>
</nav>

<main>
    <?php
    require "makeDBConnection.php";
    $sql = "SELECT * FROM users_employees";
    $result = $conn->query($sql);
    ?>

    <table>
        <thead>
        <tr>
            <th>Employee ID</th>
            <th>Employee First Name</th>
            <th>Employee Last Name</th>
            <th>Password</th>
            <th>Salary</th>
        </tr>
        </thead>
        <tbody>
        <?php
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['user_id'] . "</td>";
            echo "<td>" . $row['username'] . "</td>";
            echo "<td>" . $row['password'] . "</td>";
            echo "<td>" . $row['email'] . "</td>";
            echo "<td>" . $row['user_type'] . "</td>";
            echo "<td>" . $row['salary'] . "</td>";
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
</main>

<footer>
</footer>
</body>
</html>
