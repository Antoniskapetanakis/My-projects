<?php
require "makeDBConnection.php";
function getReservationDetails($reservationId) {
global $conn;

$sql = "SELECT room_type, check_in_date, check_out_date, status FROM reservations WHERE reservation_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $reservationId);
$stmt->execute();
$stmt->bind_result($roomType, $checkInDate, $checkOutDate, $status);
$stmt->fetch();
$stmt->close();
    return [
'room_type' => $roomType,
'check_in_date' => $checkInDate,
'check_out_date' => $checkOutDate,
'status' => $status,
];
}
function isRoomAvailable($roomType, $checkInDate, $checkOutDate) {
global $conn;
$sql = "SELECT COUNT(*) FROM reservations WHERE room_type = ? AND status = 'approved' AND ((check_in_date <= ? AND check_out_date >= ?) OR (check_in_date <= ? AND check_out_date >= ?))";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssss", $roomType, $checkInDate, $checkOutDate, $checkInDate, $checkOutDate);
$stmt->execute();
$stmt->bind_result($count);
$stmt->fetch();
$stmt->close();

return $count == 0;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
$reservationId = $_POST["reservation_id"];
$action = $_POST["action"];
if ($action == "approve") {
$reservationDetails = getReservationDetails($reservationId);

$isRoomAvailable = isRoomAvailable($reservationDetails['room_type'], $reservationDetails['check_in_date'], $reservationDetails['check_out_date']);
if ($isRoomAvailable) {
$sql = "UPDATE reservations SET status = 'approved' WHERE reservation_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $reservationId);
$stmt->execute();
$stmt->close();
$message = "Reservation approved!";
} else {
$message = "Room is not available for the selected dates. Reservation cannot be approved.";
}
} elseif ($action == "decline") {
$sql = "UPDATE reservations SET status = 'declined' WHERE reservation_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $reservationId);
$stmt->execute();
$stmt->close();
$message = "Reservation declined!";
}
}


$sql = "SELECT reservation_id, user_id, room_type, check_in_date, check_out_date, status FROM reservations";
$result = $conn->query($sql);
?>
<header>
<style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
    }
    header {
      background-color: #333;
      padding: 10px;
      text-align: center;
      color: white;
    }
    nav {
      background-color: #f4f4f4;
    }
    ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
      overflow: hidden;
    }
    li {
      float: left;
    }
    a {
      display: block;
      color: #333;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
    }
    a:hover {
      background-color: #ddd;
    }
    #logo {
      max-width: 150px;
      height: auto;
      display: block;
      margin: 0 auto;
    }
    h1 {
      text-align: center;
    }
    table {
      width: 80%;
      margin: 20px auto;
      border-collapse: collapse;
      background-color: white;
    }
    th, td {
      border: 1px solid black;
      padding: 10px;
      text-align: left;
    }
    th {
      background-color: #333;
      color: white;
    }
    form {
      display: inline-block;
    }
  </style>
</head>
<title>Reservations</title>
<img id="logo" src="movie logo.jpg" alt="">
</header>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<script src="script.js" defer></script> 
<nav>
<ul>
<li><a href="index.php">Home</a></li>
<li><a href="about.html">About</a></li>
<li><a href="contact.php">Contact</a></li>
<li><a href="upcoming.html">Upcoming</a></li>
<li><a href="Privacy Policy.html">Privacy Policy</a></li>
<li><a href="Privacy Policy.html">Privacy Policy</a></li>
</ul>				
</nav>
<ul>
<h3>Employee Settings:</h3>
<li><a href="index.php">Home</a></li>
<li><a href="manage system.php">System</a></li>
<li><a href="approve reservations.php">Reservations</a></li>
<li><a href="set_schedule.php">Schedule</a></li>
<li><a href="movie_operations.php">Edit Movie</a></li>

</ul>
</nav>
 <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
    }

    header {
      background-color: #333;
      padding: 10px;
      text-align: center;
      color: white;
    }

    nav {
      background-color: #f4f4f4;
    }

    ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
      overflow: hidden;
    }

    li {
      float: left;
    }

    a {
      display: block;
      color: #333;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
    }

    a:hover {
      background-color: #ddd;
    }


    .w3-max-150 {
      max-width: 150px;
      height: auto; 
      display: block;
      margin: 0 auto;
    }
  </style>
</head>
  
 <h1>Reservations:</h1>

<?php
if (isset($message)) {
echo "<p>$message</p>";
}
?>

<table border="1">
<tr>
<th>Reservation ID</th>
<th>User ID</th>
<th>Room Type</th>
<th>Check-in Date</th>
<th>Check-out Date</th>
<th>Status</th>
<th>Action</th>
</tr>
<?php
while ($row = $result->fetch_assoc()) {
echo "<tr>";
echo "<td>" . $row["reservation_id"] . "</td>";
echo "<td>" . $row["user_id"] . "</td>";
echo "<td>" . $row["room_type"] . "</td>";
echo "<td>" . $row["check_in_date"] . "</td>";
echo "<td>" . $row["check_out_date"] . "</td>";
echo "<td>" . $row["status"] . "</td>";
echo "<td>";
if ($row["status"] == "pending") {
echo "<form method='post' action=''>";
echo "<input type='hidden' name='reservation_id' value='" . $row["reservation_id"] . "'>";
echo "<select name='action'>";
echo "<option value='approve'>Approve</option>";
echo "<option value='decline'>Decline</option>";
echo "</select>";
echo "<input type='submit' value='Submit'>";
echo "</form>";
} else {
echo "N/A";
            }
echo "</td>";
echo "</tr>";
}
?>
</table>
<a href="employee_dashboard.php">Back to Dashboard</a>
   
</body>
</html>

