<?php
$servername = "localhost:3306";
$username = "root";
$password = "";
$dbname = "movies";
?>