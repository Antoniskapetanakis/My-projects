<?php
require "makeDBConnection.php";

function sanitizeInput($input) {

return $input;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
$user_id = sanitizeInput($_POST["user_id"]);
$newEmail = sanitizeInput($_POST["new_email"]);
$sql = "UPDATE users_employees SET email = ? WHERE user_id = ?";
$stmt = $conn->prepare($sql);
if ($stmt) {
$stmt->bind_param("si", $newEmail, $user_id);
$stmt->execute();
if ($stmt->affected_rows > 0) {
echo "Email updated successfully.";
} else {
echo "Failed to update email.";
}
$stmt->close();
} else {
echo "Failed to prepare statement.";
}
}

$sql = "SELECT user_id, username, email FROM users_employees";
$result = $conn->query($sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<title>Manage User Accounts</title>
<style>
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
    }
    header {
      background-color: #333;
      padding: 10px;
      text-align: center;
      color: white;
    }
    img {
      max-width: 150px;
      height: auto;
      display: block;
      margin: 0 auto;
    }
    ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
      overflow: hidden;
      background-color: #333;
    }
    li {
      float: left;
    }
    a {
      display: block;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
    }
    a:hover {
      background-color: #ddd;
      color: black;
    }
    h1, h2 {
      text-align: center;
    }
    form {
      text-align: center;
      margin-bottom: 20px;
    }
    table {
      margin: 0 auto;
      border-collapse: collapse;
      width: 80%;
      background-color: white;
    }
    table, th, td {
      border: 1px solid #ddd;
    }
    th, td {
      padding: 10px;
      text-align: left;
    }
    th {
      background-color: #f2f2f2;
    }
    a.back-link {
      display: block;
      text-align: center;
      margin-top: 20px;
      color: #333;
      text-decoration: none;
      font-weight: bold;
    }
    a.back-link:hover {
      background-color: #ddd;
    }
  </style>
</head>
</head>
<body>
<header>
<img id="logo" src="movie logo.jpg" alt="">
</header>
<ul>
<li><a href="index.php">Home</a></li>
<li><a href="about.html">About</a></li>
<li><a href="contact.php">Contact</a></li>
<li><a href="upcoming.html">Upcoming</a></li>
<li><a href="Privacy Policy.html">Privacy Policy</a></li>
</ul>

<ul>
<h3>Employee Settings:</h3>
<li><a href="index.php">Home</a></li>
<li><a href="manage system.php">System</a></li>
<li><a href="approve reservations.php">Reservations</a></li>
<li><a href="set_schedule.php">Schedule</a></li>
<li><a href="movie_operations.php">Edit Movie</a></li>

</ul>
</nav>
<h1>Manage User Accounts</h1>

<form method="post" action="">
<label for="user_id">User ID:</label>
<input type="text" name="user_id" required>
<label for="new_email">New Email:</label>
<input type="email" name="new_email" required>
<input type="submit" value="Update Email">
</form>

<h2>User Information</h2>
<table border="1">
<tr>
<th>User ID</th>
<th>Username</th>
<th>Email</th>
</tr>
<?php
while ($row = $result->fetch_assoc()) {
echo "<tr>";
echo "<td>" . $row["user_id"] . "</td>";
echo "<td>" . $row["username"] . "</td>";
echo "<td>" . $row["email"] . "</td>";
echo "</tr>";
        }
        ?>
</tabl
<a href="employee_dashboard.php">Back to Dashboard</a>
</body>
</html>
