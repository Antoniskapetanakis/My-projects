<?php
require "makeDBConnection.php";
function sanitizeInput($input) {
return $input;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
$email = sanitizeInput($_POST["email"]);
$password = sanitizeInput($_POST["password"]);


$stmt = $conn->prepare("SELECT user_type, password FROM users_employees WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
$stmt->bind_result($user_type, $storedPassword);
$stmt->fetch();

if (password_verify($password, $storedPassword)) {
if ($user_type == "user") {
echo json_encode(["login successfull"]);
echo json_encode(["Welcome,user"]);

} elseif ($user_type == "employee") {
echo json_encode(["status" => "success", "user_type" => "employee"]);
header("Location: employee_dashboard.php");
exit();
}
} elseif ($user_type == "") {
echo json_encode(["status" => "success", "user_type" => "admin"]);
header("Location: admin.php");
exit();
}
} else {
echo json_encode(["invalid email or password"]);
}
} else {
echo json_encode(["user not found"]);
}

$stmt->close();


$conn->close();
?>