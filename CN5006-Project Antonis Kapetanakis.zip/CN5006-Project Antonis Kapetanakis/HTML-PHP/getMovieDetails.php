<?php
require "makeDBConnection.php";

if (isset($_GET['movieId'])) {
$movieId = $_GET['movieId'];

$stmt = $conn->prepare("SELECT * FROM movies WHERE id = ?");
$stmt->bind_param("i", $movieId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
$movieDetails = $result->fetch_assoc();
header('Content-Type: application/json');
echo json_encode($movieDetails);
} else {
header('Content-Type: application/json');
echo json_encode(["error" => "Movie not found"]);
}
$stmt->close();
} else {
header('Content-Type: application/json');
echo json_encode(["error" => "Invalid request"]);
}
$conn->close();
?>
