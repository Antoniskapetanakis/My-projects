<?php
require "makeDBConnection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $day = $_POST["day"];
    $start_time = $_POST["start_time"];
    $end_time = $_POST["end_time"];
    $user_id = 1;

    $sql = "INSERT INTO schedule (user_id, day, start_time, end_time) VALUES (?, ?, ?, ?)";
   
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('isss', $user_id, $day, $start_time, $end_time);
    
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "Schedule set successfully.";
    } else {
        echo "Failed to set schedule.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Set Schedule</title>
</head>
<body>
    <header>
        <img id="logo" src="movie logo.jpg" alt="">
    </header>

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <script src="script.js" defer></script>
    
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="upcoming.html">Upcoming</a></li>
            <li><a href="Privacy Policy.html">Privacy Policy</a></li>
        </ul>
        <ul>
            <h3>Employee Settings:</h3>
            <li><a href="index.php">Home</a></li>
            <li><a href="manage system.php">System</a></li>
            <li><a href="approve reservations.php">Reservations</a></li>
            <li><a href="set_schedule.php">Schedule</a></li>
            <li><a href="movie_operations.php">Edit Movie</a></li>
        </ul>
    </nav>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        header {
            background-color: #333;
            padding: 10px;
            text-align: center;
            color: white;
        }

        #logo {
            max-width: 150px;
            height: auto;
            display: block;
            margin: 0 auto;
        }

        nav {
            background-color: #f4f4f4;
        }

        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
        }

        li {
            float: left;
        }

        a {
            display: block;
            color: #333;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        a:hover {
            background-color: #ddd;
            color: black;
        }

        h1 {
            text-align: center;
        }

        form {
            text-align: center;
            margin: 20px;
        }

        label {
            margin-right: 10px;
        }

        input {
            margin-bottom: 10px;
        }

        button {
            padding: 10px;
            background-color: #333;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #555;
        }

        a.back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #333;
            text-decoration: none;
            font-weight: bold;
        }

        a.back-link:hover {
            background-color: #ddd;
        }
    </style>

    <h1>Set Schedule</h1>

    <form method="post" action="">
        <label for="day">Day:</label>
        <input type="text" name="day" required>
        <br>
        <label for="start_time">Start Time:</label>
        <input type="text" name="start_time" required>
        <br>
        <label for="end_time">End Time:</label>
        <input type="text" name="end_time" required>
        <br>
        <button type="submit">Set Schedule</button>
    </form>

    <a href="employee_dashboard.php">Back to Dashboard</a>
</body>
</html>