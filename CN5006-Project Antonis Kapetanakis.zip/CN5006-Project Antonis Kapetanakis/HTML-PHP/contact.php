
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="styles.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<script src="script.js" defer></script>
<img id="logo" src="movie logo.jpg" alt="">
<title>Contact</title>
<style>
body {
margin: 0;
padding: 0;
font-family: Arial, sans-serif;
background-color: #f4f4f4;
}
header {
background-color: #333;
color: white;
text-align: center;
padding: 10px;
}
nav {
background-color: #333;
overflow: hidden;
}
nav ul {
list-style-type: none;
margin: 0;
padding: 0;
overflow: hidden;
}
nav li {
float: left;
}

nav a {
display: block;
color: white;
text-align: center;
padding: 14px 16px;
text-decoration: none;
}

nav a:hover {
background-color: #ddd;
color: black;
}
.container {
width: 80%;
margin: 0 auto;
}
form {
margin-top: 20px;
max-width: 600px;
margin-left: auto;
margin-right: auto;
}
label {
display: block;
margin-bottom: 8px;
}
input,
textarea {
width: 100%;
padding: 10px;
margin-bottom: 10px;
box-sizing: border-box;
}
button {
background-color: black;
color: white;
padding: 10px 15px;
border: none;
border-radius: 5px;
cursor: pointer;
}
button:hover {
background-color: #45a049;
}
#message {
margin-top: 10px;
color: #black;
}
</style>
</head>

<body>
    <header>
<h1>Movie Booking System</h1>
</header>

<nav>
<ul>
<li><a href="index.php">Home</a></li>
<li><a href="about.html">About</a></li>
<li><a href="contact.html">Contact</a></li>
<li><a href="upcoming.html">Upcoming</a></li>
<li><a href="Privacy Policy.html">Privacy Policy</a></li>
</ul>
</nav>

<div class="container">
<h2>Contact Us</h2>
<form action="process_contact.php" method="post">
<label for="name">Name:</label>
<input type="text" id="name" name="name" required>
<label for="email">Email:</label>
<input type="email" id="email" name="email" required>
<label for="message">Message:</label>
<textarea id="message" name="message" rows="4" required></textarea>

<button type="submit">Submit</button>
</form>
</div>

<script src="script.js"></script>
</body>
<h3> Or found us on: </h3>
<style>
body {
margin: 0;
padding: 0;
font-family: Arial, sans-serif;
background-color: #f4f4f4;
}

header {
background-color: #333;
color: white;
text-align: center;
padding: 10px;
}

nav {
background-color: #333;
overflow: hidden;
}
nav ul {
list-style-type: none;
margin: 0;
padding: 0;
overflow: hidden;
}
nav li {
float: left;
}
nav a {
display: block;
color: white;
text-align: center;
padding: 14px 16px;
text-decoration: none;
}
nav a:hover {
background-color: #ddd;
color: black;
}

.container {
width: 80%;
margin: 0 auto;
}

.social-buttons {
margin-top: 20px;
text-align: center;
}
.social-buttons a {
display: inline-block;
margin: 0 10px;
text-decoration: none;
color: #fff;
background-color: #4caf50;
padding: 10px;
border-radius: 50%;
transition: background-color 0.3s;
}
.social-buttons a:hover {
background-color: #45a049;
}</style>
</body>
  <div class="container">
<h2></h2>
<div class="social-buttons">
<a href="https://www.facebook.com/profile.php?id=100020674842478" target="_blank"><i class="fab fa-facebook-f"></i></a>
<a href="https://twitter.com/AntonisKap2" target="_blank"><i class="fab fa-twitter"></i></a>
<a href="https://www.linkedin.com/in/antonis-kap-5b8481268/" target="_blank"><i class="fab fa-instagram"></i></a>
  
<h3>telephone:6985670903
address:Irakliou 17
email:movie@booking.com </h3>
</div>
</div>
</html>

</html>
