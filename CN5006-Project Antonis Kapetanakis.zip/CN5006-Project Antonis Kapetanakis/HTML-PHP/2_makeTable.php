<?php
require "makeDBConnection.php";

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "CREATE TABLE reservations (
    reservation_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    room_type VARCHAR(255) NOT NULL,
    check_in_date DATE NOT NULL,
    check_out_date DATE NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES users_employees (user_id)
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'reservations' created successfully<br>";
} else {
    echo "Error creating table 'reservations': " . $conn->error . "<br>";
}

$sql = "CREATE TABLE schedule (
    schedule_id INT PRIMARY KEY AUTO_INCREMENT
    employee_id INT NOT NULL,
    days VARCHAR(255) NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    CONSTRAINT fk_employee FOREIGN KEY (employee_id) REFERENCES users_employees (user_id)
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'schedule' created successfully<br>";
} else {
    echo "Error creating table 'schedule': " . $conn->error . "<br>";
}

$sql = "CREATE TABLE movies (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    genre VARCHAR(50) NOT NULL,
    release_date DATE NOT NULL,
    duration_minutes INT NOT NULL,
    director VARCHAR(100) NOT NULL,
    synopsis TEXT,
    poster_url VARCHAR(255),
    trailer_url VARCHAR(255)
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'movies' created successfully<br>";
} else {
    echo "Error creating table 'movies': " . $conn->error . "<br>";
}

$sql = "CREATE TABLE bookings (
    booking_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    movie_name VARCHAR(100) NOT NULL,
    day VARCHAR(20) NOT NULL,
    time VARCHAR(20) NOT NULL,
    room VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    user_name VARCHAR(50) NOT NULL,
    seats_booked INT NOT NULL
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'bookings' created successfully<br>";
} else {
    echo "Error creating table 'bookings': " . $conn->error . "<br>";
}

$sql = "CREATE TABLE rooms (
    room_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    room_name VARCHAR(50) NOT NULL,
    capacity INT(3) NOT NULL
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'rooms' created successfully<br>";
} else {
    echo "Error creating table 'rooms': " . $conn->error . "<br>";
}

$sql = "CREATE TABLE users_employees (
      user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    user_type ENUM('user', 'employee') NOT NULL
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'users_employees' created successfully<br>";
} else {
    echo "Error creating table 'users_employees': " . $conn->error . "<br>";
}


$conn->close();
?>
