<?php
require "makeDBConnection.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $day = $_POST["day"]; 
    $time = $_POST["time"];
    $room = $_POST["room"];
    $seats_booked = $_POST["seats_booked"]; 

    $stmt = $conn->prepare("INSERT INTO bookings (day, time, room, seats_booked) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $day, $time, $room, $seats_booked); // Correct variable name

    if ($stmt->execute()) {
        echo "Booking submitted successfully!";
    } else {
        echo "Error submitting booking: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request method.";
}
?>
