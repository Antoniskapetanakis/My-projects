<?php
require "makeDBConnection.php";

$roomsData = array(
    array('First', 'Mini', 50),
    array('Second', 'Small', 100),
    array('Third', 'Medium', 200),
    array('Fourth', 'Large', 300),
    array('Fifth', 'Ultra', 500),
);

foreach ($roomsData as $room) {
    $sql = "INSERT IGNORE INTO rooms (room_id, room_name, capacity) VALUES ('$room[0]', '$room[1]', $room[2])";

    if ($conn->query($sql) === TRUE) {
        echo "Record inserted successfully into rooms table for $room[1] room.<br>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$movies = array(
    array('Inception', 'Science Fiction', '2010-07-16', 148, 'Christopher Nolan', 'A thief who enters the dreams of others to steal their secrets.', 'inception.jpg', 'inception_trailer_url'),
    array('Godzilla: King of the Monsters', 'Action', '2019-05-31', 132, 'Michael Dougherty', 'Godzilla battles against ancient super-species.', 'Godzilla King of the Monsters.jpg', 'godzilla_trailer_url'),
    array('Alien', 'Science Fiction', '1979-05-25', 117, 'Ridley Scott', 'A deadly extraterrestrial creature terrorizes the crew of a spaceship.', 'alien.jpg', 'alien_trailer_url'),
    array('The Lord of the Rings: The Return of the King', 'Fantasy', '2003-12-17', 201, 'Peter Jackson', 'The final battle for Middle-earth unfolds as the Fellowship fights against Sauron.', 'lord of the rings the return of the king.jpg', 'lotr_trailer_url'),
    array('Avengers: Endgame', 'Action', '2019-04-26', 181, 'Anthony and Joe Russo', 'The Avengers assemble for a final showdown against Thanos to save the universe.', 'avengers-endgame.jpg', 'avengers_trailer_url')
);

foreach ($movies as $movie) {
    $sql = "INSERT INTO movies (title, genre, release_date, duration_minutes, director, synopsis, poster_url, trailer_url) VALUES ('$movie[0]', '$movie[1]', '$movie[2]', $movie[3], '$movie[4]', '$movie[5]', '$movie[6]', '$movie[7]')";

    if ($conn->query($sql) === TRUE) {
        echo "Record inserted successfully for movie $movie[0].<br>";
    } else {
        echo "Error inserting record for movie $movie[0]: " . $conn->error . "<br>";
    }
}

$userPassword = password_hash("Kapgamers", PASSWORD_DEFAULT);
$employeePassword = password_hash("Antoniskape", PASSWORD_DEFAULT);
$adminPassword = password_hash("Admin_password", PASSWORD_DEFAULT);

$sqlUsers = "INSERT IGNORE INTO users_employees (user_id, username, password, email, user_type)
VALUES
(11, 'admin', '$adminPassword', 'admin@example.com', 'admin'),
(1, 'John', '$userPassword', 'John@example.com', 'user'),
(2, 'Jim', '$userPassword', 'Jim@example.com', 'user'),
(3, 'George', '$userPassword', 'George@example.com', 'user'),
(4, 'Pete', '$userPassword', 'Pete@example.com', 'user'),
(5, 'Lem', '$userPassword', 'Lem@example.com', 'user')";

$sqlEmployees = "INSERT IGNORE INTO users_employees (user_id, username, password, email, user_type, salary)
VALUES
(6, 'Gianne', '$employeePassword', 'Gianne@example.com', 'employee', 6000),
(7, 'David', '$employeePassword', 'David@example.com', 'employee', 7000),
(8, 'Lucky', '$employeePassword', 'Lucky@example.com', 'employee', 8000),
(9, 'Jack', '$employeePassword', 'Jack@example.com', 'employee', 9000),
(10, 'Kate', '$employeePassword', 'Kate@example.com', 'employee', 10000)";

if ($conn->query($sqlUsers) === TRUE && $conn->query($sqlEmployees) === TRUE) {
    echo "Records inserted successfully into users_employees table.<br>";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>

