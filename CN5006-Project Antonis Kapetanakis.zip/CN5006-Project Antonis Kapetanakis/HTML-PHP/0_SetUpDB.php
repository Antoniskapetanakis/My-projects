<?php
require "1_makeDB.php";
require "2_makeTable.php";
require "3_makeInsert.php";
require "authenticator.php";
?>