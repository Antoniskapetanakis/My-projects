<?php
 require "makeDBConnection.php";
function sanitizeInput($input) {
return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

$name = sanitizeInput($_POST["name"]);
$email = sanitizeInput($_POST["email"]);
$message = sanitizeInput($_POST["message"]);


$timestamp = date("Y-m-d H:i:s");
$formData = [
'Timestamp' => $timestamp,
'Name' => $name,
'Email' => $email,
'Message' => $message,
];

$jsonData = json_encode($formData, JSON_PRETTY_PRINT);
$filePath = 'contact_messages.json';
file_put_contents($filePath, $jsonData . PHP_EOL, FILE_APPEND);
header("Location: thank_you.html");
exit();
}
?>