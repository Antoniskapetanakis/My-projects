<?php
require "makeDBConnection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (!isset($_POST["username"])) {
        echo "Error: Username is not set.";
        exit();
    }
    $username = mysqli_real_escape_string($conn, $_POST["username"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

    $checkExistingQuery = "SELECT * FROM users_employees WHERE username = ? OR email = ?";
    $checkExistingStmt = $conn->prepare($checkExistingQuery);
    $checkExistingStmt->bind_param("ss", $username, $email);
    $checkExistingStmt->execute();
    $result = $checkExistingStmt->get_result();

    if ($result->num_rows > 0) {
        
        echo "Username or email already exists. Please choose a different username or email.";
    } else {
        $insertUserQuery = "INSERT INTO users_employees (username, password, email, user_type) VALUES (?, ?, ?, 'user')";
        $insertUserStmt = $conn->prepare($insertUserQuery);
        $insertUserStmt->bind_param("sss", $username, $password, $email);

        if ($insertUserStmt->execute()) {
            echo "Registration successful. You can now log in.";
        } else {
            echo "Error inserting record: " . $insertUserStmt->error;
        }
        $insertUserStmt->close();
    }
    $checkExistingStmt->close();
}

$conn->close();
?>

