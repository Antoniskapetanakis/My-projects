//The whole Javascript code of the project//.
<script>
const seatContainer = document.getElementById("seatContainer");
const seatsBookedInput = document.getElementById("seats_booked");
let selectedSeats = [];

for (let i = 1; i <= 50; i++) {
const seat = document.createElement("div");
seat.className = "seat";
seat.dataset.seatNumber = i;
seat.addEventListener("click", toggleSeat);
seatContainer.appendChild(seat);
}

function toggleSeat(event) {
const clickedSeat = event.target;
const seatNumber = clickedSeat.dataset.seatNumber;

if (selectedSeats.includes(seatNumber)) {
selectedSeats = selectedSeats.filter(seat => seat !== seatNumber);
clickedSeat.classList.remove("booked");
} else {
selectedSeats.push(seatNumber);
clickedSeat.classList.add("booked");
}

updateSeatsBookedInput();
}
function updateSeatsBookedInput() {
seatsBookedInput.value = selectedSeats.join(", ");
}
function openMovieModal(movieId) {
const xhr = new XMLHttpRequest();
xhr.onreadystatechange = function () {
if (xhr.readyState === 4 && xhr.status === 200) {
const movieDetails = JSON.parse(xhr.responseText);
displayMovieDetails(movieDetails);
}
};
xhr.open("GET", "getMovieDetails.php?movieId=" + movieId, true);
xhr.send();
}

function displayMovieDetails(movie) {
const modalTitle = document.getElementById("modalTitle");
const modalContent = document.getElementById("modalContent");
modalTitle.textContent = movie.title;
modalContent.innerHTML = `
<p><strong>Genre:</strong> ${movie.genre}</p>
<p><strong>Duration:</strong> ${movie.duration_minutes} mins</p>
<p><strong>Director:</strong> ${movie.director}</p>
<p><strong>Synopsis:</strong> ${movie.synopsis || "No synopsis available"}</p>
<p><strong>PG:U18</strong></p>
<p><strong>Trailer:</strong> ${movie.trailer_url ? `<a href="${movie.trailer_url}" target="_blank">Watch Trailer</a>` : "No trailer available"}</p>
`;
document.getElementById("movieModal").style.display = "block";
}

function closeMovieModal() {
document.getElementById("movieModal").style.display = "none";
}
function goBack() {
document.getElementById("movieModal").style.display = "none";
}
function openBookingModal() {
document.getElementById("bookingModal").style.display = "block";
}

function closeBookingModal() {
document.getElementById("bookingModal").style.display = "none";
}
function submitBooking() {
const selectedDay = document.getElementById("day").value;
const selectedTime = document.getElementById("time").value;
const selectedRoom = document.getElementById("room").value;
const selectedSeats = document.getElementById("seats_booked").value;
const xhr = new XMLHttpRequest();
xhr.onreadystatechange = function () {
if (xhr.readyState === 4 && xhr.status === 200) {
console.log("Booking submitted successfully!");
closeBookingModal();
displayBookingMessage("Your reservation request is successful!");
}
};

const url = "book movie.php";		
const data = `day=${selectedDay}&time=${selectedTime}&room=${selectedRoom}&seats_booked=${selectedSeats}`;
xhr.open("POST", url, true);
xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xhr.send(data);
}
function displayBookingMessage(message) {
alert(message);
}
</script>
<script>
function acceptCookies() {
document.cookie = "cookie_accepted=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/";
document.getElementById('cookie-consent').style.display = 'none';
}
function declineCookies() {   
document.getElementById('cookie-consent').style.display = 'none';
}
</script>
<script>
function acceptNotifications() {
document.cookie = "notification_accepted=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/";
alert('You have allowed notifications.');
document.getElementById('notification-consent').style.display = 'none';
}
function blockNotifications() {
alert('You have blocked notifications.');
document.getElementById('notification-consent').style.display = 'none';
}
</script>
<script>
const upcomingMovies = [
{
title: 'Batman Κ18',
poster: 'https://i5.walmartimages.com/asr/9fea481e-c606-4ed7-b94c-3e1a020a3dd7.d3fca58269d598e0c600813db6eb07b4.jpeg',
releaseDate: '2024-01-15',
genre: 'Action, Crime, Drama',
synopsis: 'The Dark Knight rises to face new challenges in Gotham City.'
},
{
title: 'Spiderman Κ15',
poster: 'https://i5.walmartimages.com/asr/ab8f90ea-3008-4fef-a9ec-5efd798c6e16.fe76036af17b4217e845d9068cd8925b.jpeg',
releaseDate: '2024-02-20',
genre: 'Action, Adventure, Sci-Fi',
synopsis: 'Spiderman swings into action to save the city from new threats.'
},
{
title: 'Psycho Α18',
poster: 'https://m.media-amazon.com/images/W/MEDIAX_792452-T2/images/I/610L8FnFWpL._AC_UF894,1000_QL80_.jpg',
releaseDate: '2024-03-25',
genre: 'Horror, Mystery, Thriller',
synopsis: 'A suspenseful tale of mystery and psychological terror at Bates Motel.'
},
{
title: 'Tenet Κ18',
poster: 'https://m.media-amazon.com/images/I/91BnDPpVcBL.jpg',
releaseDate: '2024-04-30',
genre: 'Action, Sci-Fi, Thriller',
synopsis: 'A time-bending thriller exploring the world of international espionage.'
},
{
title: 'Interstellar Κ18',
poster: 'https://i.etsystatic.com/23402008/r/il/b658b2/2327469308/il_570xN.2327469308_492n.jpg',
releaseDate: '2024-05-15',
genre: 'Adventure, Drama, Sci-Fi',
synopsis: 'A journey through space and time to save humanity on a dying Earth.'
}
];
function renderMovies() {
const movieContainer = document.getElementById('movieContainer');
upcomingMovies.forEach(movie => {
const card = document.createElement('div');
card.classList.add('movie-card');
const poster = document.createElement('img');
poster.src = movie.poster;
poster.alt = `${movie.title} Poster`;
poster.classList.add('movie-poster');
const title = document.createElement('h2');
title.textContent = movie.title;
const releaseDate = document.createElement('p');
releaseDate.textContent = `Release Date: ${movie.releaseDate}`;
const genre = document.createElement('p');
genre.textContent = `Genre: ${movie.genre}`;
const synopsis = document.createElement('p');
synopsis.textContent = movie.synopsis;
card.appendChild(poster);
card.appendChild(title);
card.appendChild(releaseDate);
card.appendChild(genre);
card.appendChild(synopsis);
movieContainer.appendChild(card);
});
}
renderMovies();
</script>